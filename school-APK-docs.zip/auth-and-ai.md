---
name: auth-and-ai
description: Authentication flow, test users, JWT details, AI gateway setup, local-echo mode, and service-to-service auth
type: project
---

## Authentication & Login (CRITICAL — check every session)
- **JWT expiry**: 900 seconds (15 min). Must re-login every session.
- **`deviceFingerprint` is a JSON OBJECT** — NOT a string/hash:
  ```json
  { "userAgent": "...", "deviceId": "...", "ipSubnet": "..." }
  ```
  Sending a plain string causes 400/500 errors.
- **captchaToken format**: `"{challengeId}:{answer}"` (colon-delimited). E2E bypass: `"E2E-LOCAL-BYPASS-DO-NOT-USE-IN-PROD:bypass"` (the bypass token IS the challengeId part, before the colon)
- **Get captcha answer**: `docker exec edutech-redis redis-cli -a redis_dev_pass_2026 GET "captcha:{id}"`
- **Zustand persist key**: `edupath-auth` in localStorage → `{state:{token,user,isAuthenticated:true},version:0}`
- **ALL test user passwords**: `Test@12345` (Argon2id hash via argon2-cffi, p=4 — CRITICAL parameter)

## Test Users
| Email | Role | UUID |
|---|---|---|
| `admin1@test.com` | SUPER_ADMIN | `008f804f-ce93-4e35-87af-77fdc7d68fa3` |
| `teacher1@test.com` | TEACHER | `55c42189-4b43-462a-876a-c142d84e2850` |
| `parent1@test.com` | PARENT | `30a06234-4e3d-4fa0-91a3-7705646c2b21` |
| `qa-test@nexused.dev` | STUDENT | `50d63f9c-9b9c-4737-a66a-22b29dad42a1` |

- `parent1@test.com` display name: **Suresh Verma** (corrected in both auth_schema.users AND parent_schema.parent_profiles)
- `parent1@test.com` phone: `9964636666` (used for SMS dev-echo)
- Parent profile ID (NOT user ID): `59ca5bc7-f8ed-4f93-8808-9262ebc2f1af`

## Service-to-Service Auth (ai-gateway-svc)
- All callers (parent-svc, ai-mentor-svc) must send `X-Service-Key: edutech-internal-svc-2026`
- WebClientConfig beans MUST add `.defaultHeader("X-Service-Key", serviceApiKey)`
- Completions endpoint: `POST /api/v1/ai/completions` → `{requesterId, systemPrompt, userMessage, maxTokens, temperature}`
- Response field: `content` (String) — `AiGatewayHttpClient` reads `response.get("content")`
- LlmProvider enum: `ANTHROPIC` (default/@Primary), `OPENROUTER` (@Qualifier("openRouterLlmClient")), `OPENAI` (embeddings), `OLLAMA` (psych sidecar)
- **Active provider**: `AI_DEFAULT_PROVIDER=OPENROUTER` in `.env` → `LlmRoutingService.resolveProvider()`
- **OpenRouter model**: `arcee-ai/trinity-large-preview:free` (free tier, supports system prompts)

## AI Local-Echo Mode
- When `ANTHROPIC_API_KEY` starts with `sk-ant-dev` or blank → `AnthropicWebClientAdapter.isPlaceholderKey()` → `executeLocalEcho()`
- OpenRouter: `OPENROUTER_API_KEY` starts with `or-dev` → same keyword-based echo
- `executeLocalEcho()` inspects systemPrompt/userMessage keywords and returns contextually appropriate responses
- All AI features (Parent Copilot, Student AI Mentor, Doubt Resolver, Career Oracle) work without a real API key
- If copilot shows "unable to connect": verify ai-gateway-svc is running on 8086 and `SERVICE_API_KEY` matches
