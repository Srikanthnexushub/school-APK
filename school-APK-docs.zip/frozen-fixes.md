---
name: frozen-fixes
description: All permanently frozen code fixes that must NEVER be reverted, modified, refactored, or simplified under any circumstances (commits: d0a1311 → current, 98+ fixes)
type: feedback
---

## ⛔ FROZEN FIXES — NEVER REVERT, NEVER MODIFY
Commits: d0a1311, 992a3b4, c5724fc, c431206, 3fb2442, 0245235, b10dcdf, 0f63d0d, e5f395e, 858bbcf, 9f349cf, 496537f, 8e4d740, 7c7260e, 3d6f566, 4c3623d, 4bec1a8, 5c483e3, 944f801, 6f3a7cd, ac81927, 938431b, 275e718, e91af5e, bf89c7c, 5bd149f, 8bd6075, 7356635, 3db3717, 7f42ea8, 03fca46, 04d856a, 718d5c9, 6c45f2d, ccf4fae, b54547a, 5c270e6, f045a38, c20394d, 6a4a56a, 9cb5109, 5d86803, 2fa6198, b9e4062, e843293, 4458d30, 1b19097, 7f01c7b, d301e53, 52af1c3, 039cd74, d0ee154, 7f01e5d, c75c549, bd6964e, b46b775, bf69e3d, 2b19f4d, b72784e, dc33618, ef1b472, aa2cbd5, 08f6182, b7f137f, a41d586, 569396b, ba70c91, 6b23f51, 2666427, 3288e02, 9e9ddbc, 78fb9a5, 6e91249, 93703a4, fdb565e, 4bf1131, c321fd8, e384b9b, 4895229, e4122fe, eb49b83

## ⛔ PERMISSION REQUIRED — ABSOLUTE RULE
ANY modification, refactor, revert, simplification, or change to ANY code or test in this project requires **explicit user permission BEFORE making changes**. This includes:
- Bug fixes and "improvements"
- Dependency updates and migrations
- Refactoring frozen test files
- Modifying GlobalExceptionHandler mappings
- Changing any frozen test assertions or service logic

**Ask first. Act only after user says yes. No exceptions.**

## ⚠️ PERMANENT OPERATIONAL RULE — Rebuild + Restart After Every Java Commit
After any commit that changes Java source (especially `Role.java` which exists in 6+ services), running JARs are stale. Symptoms: 403 errors, `IllegalArgumentException: No enum constant Role.XYZ`.

**Permanent fix** (explicitly granted permission — 2026-03-21):
- Use `bash scripts/start-all.sh --no-build` after Java commits — it auto-detects stale JARs via mtime comparison and rebuilds only changed services.
- For targeted manual restart: kill PID → `mvn package -pl services/X -am -DskipTests -q` → `nohup java -jar ... &`
- Claude MAY run rebuild+restart operations **without asking** when: (a) a Java commit was just made and (b) services return 403/500 due to stale JARs. This is the ONE exception to the ask-first rule — it is pure operational, no code changes.

---

### Fix #1 — ParentCopilotPage.tsx: linkedStudents Page<> extraction
File: `frontend/web/src/pages/parent/ParentCopilotPage.tsx` (~line 235)
```js
queryFn: () => api.get(...).then((r) => { const d = r.data; return Array.isArray(d) ? d : (d.content ?? []); })
```
**Why frozen**: Spring returns `Page<T>`, not array. Without this, `studentId` is never sent → copilot hallucinates the child's name.

---

### Fix #2 — CopilotService.java: resolveStudentName uses profile ID NOT user ID
File: `services/parent-svc/src/main/java/com/edutech/parent/application/service/CopilotService.java`
`student_links.parent_id` stores **parent profile ID** (`59ca5bc7...`), NOT JWT user ID (`30a06234...`).
Must call `parentProfileRepository.findByUserId(userUuid)` first, then use `profile.getId()`.
**Why frozen**: Changing to userId causes null lookup → hallucinated child names.

---

### Fix #3 — CopilotService.java: ParentProfileRepository constructor injection
File: `services/parent-svc/src/main/java/com/edutech/parent/application/service/CopilotService.java`
`ParentProfileRepository` is a constructor dependency. Never remove it.
**Why frozen**: Required for Fix #2.

---

### Fix #4 — MentorPortalExamsPage.tsx: exam row expand shows live questions (commit 992a3b4)
Clicking an exam row calls `GET /api/v1/exams/{examId}/questions` (enabled only when expanded).
Correct answer option highlighted green via `correctAnswer` index.
**Why frozen**: Never remove or mock this — teacher needs to see real exam questions.

---

### Fix #5 — MentorPortalInsightsPage.tsx: AI Career Coach tab (commit 992a3b4)
`CareerCoachSection` passes real stats (exams.length, avgScore%, passRate%, batches.length) to
`POST /api/v1/ai/completions` with `requesterId: 'teacher-career-coach'`.
Uses existing queries (`publishedExams`, `overviewSubmissions`, `overviewBatches`) — no extra API calls.
`teacherName` comes from `user?.name ?? 'Teacher'` — `User` type has `name`, NOT `firstName`/`lastName`.

---

### Fix #6 — AnthropicWebClientAdapter + OpenRouterWebClientAdapter: teacher career local-echo
Branch: `sys.contains("teacher career") || sys.contains("teaching skill") || sys.contains("career coach")`
Returns structured Bloom's taxonomy + 30/90-day focus + career growth advice.
**Why frozen**: Without this, teacher AI coach returns generic/wrong response in dev mode.

---

### Fix #7 — Real-time IN_APP notification system — ENTIRE FEATURE (commits c5724fc + c431206)
All files below are frozen. Never refactor, simplify, inline, or restructure:
- `notification-svc`: `NotificationService`, `NotificationEventConsumer`, `SseEmitterRegistry`, `InAppNotificationSender`, `TwilioSmsSender`, `NotificationChannel` (EMAIL/PUSH/IN_APP/SMS), `Notification` domain entity (with `recipient_phone` field), `NotificationCommand` (7-arg with `recipientPhone`), `TwilioProperties`
- `parent-svc`: `AssessEventConsumer` — dual-channel fanout: `notifyParentInApp()` + `notifyParentSms()`. **`link.getParentId()` is the PROFILE ID** — uses `parentProfileRepository.findById()`. Never change to user ID.
- `libs/event-contracts`: `NotificationSendEvent` record with `recipientPhone` field + `sms()` factory
- `frontend`: `useNotifications` hook (SSE via `fetch()`, NOT `EventSource`), `NotificationPanel.tsx` (`StudyRouteExpander` for `STUDY_ROUTE` type), bell badge in `AppLayout.tsx`
- DB migrations V2 + V3 in `notification_schema` — never revert or drop columns
- **Dev-echo mode**: `TWILIO_ACCOUNT_SID=dev_placeholder` → logs `[SMS-DEV-ECHO]`, no real HTTP call. To go live: set real SID/token/number in `.env` and restart notification-svc.
- **Phone**: `parent1@test.com` (Suresh Verma) phone = `9964636666` in `parent_schema.parent_profiles`. Never change.
- **Teacher portal route**: `/mentor-portal` (NOT `/teacher`) — role `TEACHER`

---

### Fix #8 — AiMentorPage.tsx: DoubtResolverTab auto-selects new doubt after submit (commit 3fb2442)
File: `frontend/web/src/pages/ai-mentor/AiMentorPage.tsx` — `DoubtResolverTab.submitMutation.onSuccess`
```ts
onSuccess: (response) => {
  queryClient.invalidateQueries({ queryKey: ['doubts'] });
  setNewQuestion('');
  setSelectedId(response.data.id);   // ← THIS LINE IS FROZEN
  toast.success('Doubt submitted!');
},
```
**Why frozen**: Without `setSelectedId(response.data.id)`, the right panel stays on "Select a doubt to view details" forever and the user never sees the AI answer.

---

### Fix #9 — DoubtsPage.tsx: resolutionTimeMinutes > 0 guard (commit 3fb2442)
File: `frontend/web/src/pages/ai-mentor/DoubtsPage.tsx`
```tsx
{doubt.resolutionTimeMinutes > 0 && ` · ${doubt.resolutionTimeMinutes} min response time`}
```
**Why frozen**: `{0 && "text"}` in JSX renders the literal character `0` (React falsy gotcha — only `false`/`null`/`undefined` suppress rendering, not `0`).

---

### Fix #10 — POST /api/v1/ai/generate-questions — full implementation (commit 0245235)
**Why frozen**: Endpoint was NEVER implemented in git history. Teacher Question Generator always fell through to frontend mock data. The following files are all frozen together as one unit:

- `domain/model/QuestionGenerationRequest.java` — record `{topic, difficulty, count}`
- `domain/model/GeneratedQuestion.java` — record `{questionText, options, correctAnswer (int), explanation, difficulty}`
- `domain/port/in/GenerateQuestionsUseCase.java` — use case interface
- `application/service/QuestionGenerationService.java`:
  - Builds systemPrompt containing `"question generator mode: true"` keyword (CRITICAL — this triggers local-echo)
  - Calls `routeCompletionUseCase.routeCompletion()` → parses JSON array from `content`
  - Strips markdown code fences before parsing
  - `onErrorResume` → `buildFallbackQuestions()` (template MCQs) on any error
- `api/QuestionGenerationController.java` — `POST /api/v1/ai/generate-questions`
- `AnthropicWebClientAdapter.java` + `OpenRouterWebClientAdapter.java` — local-echo branch:
  ```java
  } else if (sys.contains("question generator")) {
      reply = buildQuestionJson(request.systemPrompt(), request.userMessage());
  }
  ```
  `buildQuestionJson()` extracts topic/difficulty/count from the prompt and returns a valid JSON array matching frontend schema.

**Schema**: Frontend sends `{topic, difficulty, count}` → expects `GeneratedQuestion[]` with `correctAnswer` as 0-based int index (not letter).
**Never**: remove `"question generator mode: true"` from the systemPrompt — it's the trigger for local-echo in both adapters.

---

### Fix #11 — StudentDashboardPage.tsx: all navigation buttons wired (commit b10dcdf)
Files: `frontend/web/src/pages/dashboard/StudentDashboardPage.tsx`
All four stub buttons now navigate:
- `AI Study Plan` → `navigate('/ai-mentor')` (opens Study Plans tab, default)
- `View Details` → `navigate('/performance')`
- `View all` (Weak Areas section) → `navigate('/performance')`
- `Tracker` (Upcoming Exams section) → `navigate('/exam-tracker')`
**Why frozen**: Buttons were stubs with no onClick. Removing navigations breaks user journey.

---

### Fix #12 — Profile completion ring (topbar) + bars (settings/parent) — ALL ROLES (commits 0f63d0d, e5f395e, 858bbcf, 9f349cf, 496537f)
**Why frozen**: Real live data per role. Ring always visible in topbar next to notification bell. NEVER move, remove, or hardcode fields.

**AppLayout topbar** — `ProfileRing` SVG component + per-role queries:
- **STUDENT**: `GET /api/v1/students/me` → 8 fields: name, email, avatarUrl, phone, gender, dateOfBirth, city, stream
- **PARENT**: `GET /api/v1/parents/me` → 8 fields: name, phone, email, relationshipType, address, city, state, pincode
- **TEACHER**: `GET /api/v1/mentors/me` → 7 fields: fullName, email, avatarUrl, bio, specializations, yearsOfExperience, hourlyRate
- **CENTER_ADMIN/SUPER_ADMIN**: auth store 3 fields (name, email, avatarUrl) — no separate admin profile service exists
- All queries cached 5 min (`staleTime: 5 * 60 * 1000`) — single network call per session
- `profilePath`: PARENT → `/parent/profile`, all others → `/settings`
- Ring: SVG r=13, circ≈81.68, `-rotate-90` on SVG, `text-white text-[10px] font-extrabold` span centered absolutely
- Colour: emerald at 100%, orange (#f97316) otherwise

**Student Settings** (`SettingsPage.tsx`) — ProfileTab:
- Fetches `GET /api/v1/students/me` (shared query key `['student-profile-me']`)
- Shows skeleton bar until loaded, then real %
- Academic Details read-only card: gender, DOB, board, currentClass, stream, targetYear, city, state
- Edit form fields: name, phone, stream (select), city, state, targetYear — PATCH to `/api/v1/students/me`

**Parent Profile** (`ParentProfilePage.tsx`):
```tsx
const profileFields = [profile.name, profile.phone, profile.email, profile.relationshipType, profile.address, profile.city, profile.state, profile.pincode];
const profilePct = Math.round((profileFields.filter(Boolean).length / profileFields.length) * 100);
```

**Backend `/me` endpoints added** (frozen — never remove):
- `GET /api/v1/students/me` + `PATCH /api/v1/students/me` — student-profile-svc, resolves by `X-User-Id` header via `findByUserId`
- `GET /api/v1/mentors/me` — mentor-svc, same pattern
- Both use `X-User-Id` header injected by student-gateway JWT filter

**DB seed**: `qa-test@nexused.dev` student profile inserted (profileId `9a70299a-6aee-4f6b-b55e-19e4a9a39f3c`, userId `309e6849-967d-4be5-a61e-368f5ed25141`) with CBSE/Class 12/PCM/Bengaluru/Karnataka/2026.

---

### Fix #13 — bharatha@test.com: invalid stream enum + psychometric UX (commit 8e4d740)

**Root error — `stream = 'SCIENCE'` in DB:** `bharatha@test.com` (userId `0f8356ca-b870-42b8-a19e-3886450d41a6`) had `stream = 'SCIENCE'` in `student_schema.students`. The Java `Stream` enum only allows `PCM, PCB, COMMERCE, ARTS, VOCATIONAL`. Hibernate threw an unmapped-enum exception when `GET /api/v1/students/me` was called, returning 500 and breaking the profile ring, settings page, and downstream psych profile fetch.
- **DB fix**: `UPDATE student_schema.students SET stream = 'PCM' WHERE user_id = '0f8356ca-b870-42b8-a19e-3886450d41a6';`
- **Prevention**: `ALTER TABLE student_schema.students ADD CONSTRAINT chk_stream CHECK (stream IS NULL OR stream IN ('PCM','PCB','COMMERCE','ARTS','VOCATIONAL')), ADD CONSTRAINT chk_gender CHECK (gender IN ('MALE','FEMALE','OTHER')), ADD CONSTRAINT chk_board CHECK (current_board IN ('CBSE','ICSE','STATE_BOARD','IB','IGCSE'));`

**UX fix — psychometric empty state (PsychometricPage.tsx):** When `profile === null` (no row in `psych_schema.psych_profiles`), the page now shows an inline "Profile Not Activated — contact admin" message instead of a "Take Assessment Now" button that immediately revealed a dead-end modal.
**Why frozen**: The old UX made students think they needed to fix their student profile (in Settings), masking the real problem (no psych profile seeded by admin). Never restore the old button-then-modal flow for the `profile === null` branch.

**Psych profile seed for bharatha**: `INSERT INTO psych_schema.psych_profiles (student_id, center_id, batch_id, status) VALUES ('0f8356ca-b870-42b8-a19e-3886450d41a6','3f3c4c28-...','e5f3771a-...','ACTIVE');`

**RULE going forward**: Any manually seeded student record MUST use a valid Stream enum value. Invalid enum values in ANY `@Enumerated(EnumType.STRING)` column cause a Hibernate 500 that cascades to ALL profile-dependent features for that user. Always validate against the Java enum before inserting.

---

### Fix #14 — Profile name persistence across logout/login — ALL roles (commit 7c7260e)
**Why frozen**: Name in topbar comes from `auth_schema.users.first_name/last_name` (populated at login). No endpoint existed to update it. Changing name in Settings/Profile had zero effect after logout+login because auth-svc returned the original name.

**Backend — auth-svc:**
- `User.java`: `updateName(firstName, lastName)` domain method (updates both fields + updatedAt)
- `UpdateNameRequest.java`: new DTO record `{firstName, lastName}`
- `AuthController.java`: `PATCH /api/v1/auth/me` endpoint — uses `@AuthenticationPrincipal AuthPrincipal` to get userId, calls `updateName`, saves. Route: `api-gateway → /api/v1/auth/**`

**Backend — student-profile-svc:**
- `UpdateStudentProfileRequest.java`: added `firstName`, `lastName` fields (first two in record)
- `StudentProfile.java`: `updateName(firstName, lastName)` domain method
- `StudentProfileService.java`: calls `profile.updateName(...)` before phone/location update

**Frontend — authStore.ts:**
- Added `updateUser(partial: Partial<User>)` action — merges partial into existing user in Zustand persist store (localStorage `edupath-auth`) so name reflects immediately in topbar without re-login

**Frontend — SettingsPage.tsx (student):**
- `saveMutation` now splits `data.name` into `firstName`/`lastName`, sends BOTH to `/api/v1/students/me` AND `/api/v1/auth/me` in `Promise.all`, calls `updateUser({ name })` on success

**Frontend — ParentProfilePage.tsx:**
- `updateMutation` now splits `data.name`, sends to BOTH `/api/v1/parents/{id}` AND `/api/v1/auth/me` in `Promise.all`, calls `updateUser({ name })` on success

**NEVER**: remove the `/api/v1/auth/me` PATCH call from either frontend mutation. Without it, auth_schema.users is never updated and name reverts on every login.

---

### Fix #15 — Student Registration Group A — 6-step onboarding flow (commit 3d6f566)
**Why frozen**: Full student registration was a stub. This is the complete, tested implementation. Never revert, simplify, or merge steps.

**center-svc — public institution code lookup:**
- `CenterLookupResponse.java`: new DTO `{id, name, city}`
- `CenterRepository.java`: added `findByCode(String code)` port method
- `SpringDataCenterRepository.java`: `@Query` finds active center by code (`deletedAt IS NULL`)
- `CenterPersistenceAdapter.java`: implements `findByCode` → delegates to JPA
- `CenterService.java`: `lookupByCode(code)` → returns `Optional<CenterLookupResponse>`
- `CenterController.java`: `GET /api/v1/centers/lookup?code=` — no `@SecurityRequirement`, no auth
- `SecurityConfig.java` (center-svc): added `/api/v1/centers/lookup` to `permitAll`
- `JwtAuthenticationFilter.java` (api-gateway): added `/api/v1/centers/lookup` to `PUBLIC_PATH_PREFIXES`
- **NEVER** require auth on this endpoint — it's called pre-registration before any token exists

**auth-svc — password complexity:**
- `RegisterRequest.java`: `@Pattern(regexp = "^(?=.*[A-Z])(?=.*\\d)(?=.*[^A-Za-z0-9]).+$")` on password field
- Requires: ≥1 uppercase, ≥1 digit, ≥1 special character — enforced server-side

**student-profile-svc — subjects + gender nullable:**
- `V5__add_subjects_and_make_gender_nullable.sql`: `ADD COLUMN subjects JSONB NOT NULL DEFAULT '[]'` + `ALTER COLUMN gender DROP NOT NULL`
- `StudentProfile.java`: `@JdbcTypeCode(SqlTypes.JSON)` `List<String> subjects` + `getSubjects()`/`setSubjects()`
- `CreateStudentProfileRequest.java`: added `List<String> subjects` as last record component
- `StudentProfileResponse.java`: added `List<String> subjects` as last record component
- `StudentProfileService.java`: `createProfile` sets `profile.setSubjects(request.subjects() != null ? request.subjects() : List.of())`; `toResponse` includes `p.getSubjects()`
- **NEVER** remove the JSONB subjects column or make it non-nullable

**frontend — RegisterPage.tsx (6-step STUDENT flow):**
- Step 1: `firstName` + `lastName` in 2-column grid; 4-badge live password complexity (≥8 chars, 1 uppercase, 1 digit, 1 special char) using `watch('password')`
- Step 2: Role cards (Student/Parent/Mentor); selecting STUDENT dynamically expands stepper from 3→6 steps; STUDENT shows "Continue" only, PARENT/TEACHER shows captcha+register inline
- Step 3 (STUDENT): Academic form — phone (optional), DOB, institution code (validated via `GET /api/v1/centers/lookup?code=`), board, grade; shows `✓ {centerName}` on valid code; stores `centerId`
- Step 4 (STUDENT): CaptchaWidget + `POST /api/v1/auth/register` → stores `regToken` (accessToken)
- Step 5 (STUDENT): `GET /api/v1/centers/{centerId}/batches?size=100` with Bearer `regToken` → extracts distinct subjects → toggleable chips
- OTP step: after `POST /api/v1/otp/verify` → decodes `regToken` JWT (`.split('.')[1]` → base64 → `sub`) → `POST /api/v1/students` with regToken → student profile created; non-fatal on profile creation failure
- PARENT/TEACHER: 3-step flow (Personal → Role+Captcha+Register → OTP)
- **NEVER**: merge steps, remove the dynamic stepper expansion, remove institution code validation, or skip the regToken-authenticated batch/subject fetch
- **Tests**: `CenterLookupTest` (3 cases), `StudentProfileSubjectsTest` (2 cases) — all pass

---

### Fix #16 — Unverified account cleanup scheduler (commit 4c3623d)
**Why frozen**: Without this, PENDING_VERIFICATION users accumulate forever — DB bloat + security risk (enumerable email addresses). Schedule + retention window are config-driven, never hardcoded.

- `application.yml`: `auth.cleanup.cron` (default `0 0 * * * *`) + `auth.cleanup.retention-hours` (default `72`)
- `CleanupProperties.java`: `@ConfigurationProperties(prefix="auth.cleanup")` record — never remove
- `UserRepository` port: `findExpiredPendingVerification(Instant cutoff)` — soft-delete only, never hard-delete
- `SpringDataUserRepository`: JPQL filters `PENDING_VERIFICATION + createdAt < cutoff + deletedAt IS NULL`
- `UserCleanupScheduler`: `@Scheduled(cron="${auth.cleanup.cron}")`, calls `user.deactivate()`, logs count
- `AuthSvcApplication`: `@EnableScheduling` — NEVER remove
- **NEVER** hard-delete users — always call `deactivate()` which sets `status=DEACTIVATED + deletedAt=now()`
- **NEVER** hardcode the 72h value — always read from `CleanupProperties.retentionHours()`

---

### Fix #17 — Parental consent gate for under-13 students (commit 4c3623d)
**Why frozen**: COPPA/DPDP legal requirement. Under-13 students must have parent/guardian consent before account activation. Consent email is non-fatal (never blocks registration).

**Backend — auth-svc:**
- `V3__add_parent_email_to_users.sql`: `ADD COLUMN IF NOT EXISTS parent_email VARCHAR(255)` in `auth_schema.users`
- `User.java`: `parentEmail` field + `getParentEmail()` + 8-arg `create()` overload (7-arg kept for compat)
- `RegisterRequest.java`: nullable `String parentEmail` as last record component — no `@NotBlank`
- `UserRegistrationService.java`: passes `parentEmail` to `User.create()`; if non-null/non-blank, calls `otpService.sendOtp(parentEmail, "PARENTAL_CONSENT", "email")` in `try-catch` — failure NEVER blocks registration
- **NEVER** make `parentEmail` required — it's null for all over-13 students
- **NEVER** let consent email failure propagate — always wrap in try-catch

**Frontend — RegisterPage.tsx:**
- `calculateAge(dob)` utility — age < 13 triggers consent gate
- `consentSchema` + `ConsentData` type (zod)
- `isUnder13` + `parentEmail` state
- `steps` array: inserts `'Parental Consent'` between Academic Info and Create Account when `isUnder13 === true`
- `onStep3Submit`: calls `calculateAge(data.dateOfBirth)`, sets `isUnder13`, then `goNext()`
- `onConsentSubmit`: stores `parentEmail`, calls `goNext()`
- `onStep4Continue`: passes `parentEmail: parentEmail ?? undefined` to register API
- Step indices (consentStep, createStep, subjectsStep, otpStep) are computed from `steps` array to handle +1 shift correctly — **NEVER** hardcode step numbers

---

### Fix #18 — Subjects step skippable when center has no batches (commit 4bec1a8)
**Why frozen**: New centers/centers with no seeded batches have zero subjects available. The old guard `selectedSubjects.length === 0` always blocked progression even when there was nothing to select.

**File**: `frontend/web/src/pages/auth/RegisterPage.tsx`
```ts
function onStep5Continue() {
  if (availableSubjects.length > 0 && selectedSubjects.length === 0) {
    toast.error('Please select at least one subject');
    return;
  }
  goNext();
}
```
**Rule**: Only enforce subject selection when `availableSubjects.length > 0`. When empty, the step shows a graceful "No subjects found — add later in Settings" fallback and allows proceeding.
**NEVER** restore the bare `selectedSubjects.length === 0` guard — it blocks onboarding for valid new-center students.

---

### Fix #19 — Playwright E2E suite: 12/12 tests passing (commit 5c483e3)
**Files**: `frontend/web/playwright.config.ts`, `frontend/web/tests/e2e/`

**3 spec files (12 tests total)**:
- `login.spec.ts` — 5 tests: page load, captcha gate, successful login, wrong password, nav to register
- `registration.spec.ts` — 4 tests: stepper expansion, password badges, live institution code lookup, full OTP flow
- `parental-consent.spec.ts` — 3 tests: under-13 gate, over-13 skip, full under-13 OTP flow

**Key fixes frozen**:
1. `RegisterPage.tsx`: Added `useEffect` debounced live institution code lookup so `✓ {centerName}` appears as user types (600ms debounce), `watch3('institutionCode')` drives it. `onStep3Submit` skips re-lookup when already resolved.
2. `waitForEmail` subject: use `'Verify'` not `'OTP'` — actual subject is "Verify your EduTech account"
3. `getByText('Parental Consent', { exact: true })` — prevents strict-mode match against heading "Parental Consent Required"
4. Full-flow tests: `test.setTimeout(90_000)` — registration + email wait needs >30s
5. Role card: `getByRole('button', { name: /^student/i })` not `getByText('Student')` — avoids matching "students" in Mentor card description
6. All config via env vars: `CAPTCHA_E2E_BYPASS_TOKEN`, `E2E_EXISTING_EMAIL`, `E2E_INSTITUTION_CODE`, `E2E_MAILHOG_API`

**NEVER** revert these selectors or change `'Verify'` back to `'OTP'` in waitForEmail calls.

---

### Fix #20 — Google Sign-In, OTP resend counter, TestContainers IT tests (commit 944f801)
**Why frozen**: Group C — production-quality auth additions and integration test coverage across 5 services.

- **Google Sign-In**: Full OAuth2 Google login flow integrated into auth-svc and frontend RegisterPage/LoginPage. Never remove or stub out the Google OAuth callback handling.
- **OTP resend counter**: OTP resend is rate-limited with a visible counter in the UI. Never remove the resend limit logic or the counter display — it prevents abuse and gives users clear feedback.
- **TestContainers IT tests (all 5 services)**: Integration tests using TestContainers are present for all 5 backend services. Never delete, skip, or downgrade these to unit-only tests — they validate real DB/Kafka interactions.

---

### Fix #21 — Parent registration: phone/occupation fields, link code step, max-child limits (commit 6f3a7cd)
**Why frozen**: Parent profile creation and child-linking during registration is a complete, tested flow.

- **RegisterPage.tsx PARENT flow**: Step 2 collects `parentPhone` + `parentOccupation` (both optional); Step 3 is OTP verification; Step 4 is Link Child (skip allowed)
- **`POST /api/v1/parents`**: Sends `{ name, phone, email, occupation }` — `occupation` field is present in `CreateParentProfileRequest` and `ParentProfile.java`
- **`POST /api/v1/parents/{id}/students`**: Sends `{ studentId, studentName, centerId, relationship }` — `LinkStudentRequest` record with these 4 required fields
- **max-child limits**: `TooManyChildrenException` (max 5 children per parent) + `TooManyParentsException` (max 2 parents per student) — NEVER remove these guards
- **NEVER** remove `occupation` from `CreateParentProfileRequest` or `UpdateParentProfileRequest` records

---

### Fix #22 — OTP-based parent-child linking — ENTIRE FEATURE (commit ac81927)
**Why frozen**: Replaces insecure permanent 6-digit link code with a time-limited, parent-triggered OTP. Removing or reverting any part breaks the secure linking flow.

**Backend — student-profile-svc:**
- `V7__add_link_otp_fields.sql`: adds `link_otp VARCHAR(6)`, `link_otp_expires_at TIMESTAMPTZ`, `link_otp_parent_user_id UUID`, `link_otp_parent_name TEXT` to `student_schema.students` — NEVER drop these columns
- `StudentProfile.java`: `generateLinkOtp(parentUserId, parentName)` — generates random 6-digit code, stores with 300s expiry; `isLinkOtpValid()` — checks non-null + not expired; `clearLinkOtp()` — atomically nulls all 4 fields after successful verification. NEVER revert these domain methods.
- `InvalidLinkOtpException` → 422 UNPROCESSABLE_ENTITY in `GlobalExceptionHandler`
- **4 new endpoints (ALL FROZEN)**:
  1. `GET /api/v1/students/lookup?email=` — any authenticated user, returns `StudentLookupResponse{id, firstName, lastName, email, city, board, currentClass}`
  2. `POST /api/v1/students/link-otp/generate` — body: `{studentEmail, parentName}`, header: `X-User-Id` (parent); stores OTP on student record; returns `{studentId, studentName, expiresAt}` — OTP is NOT returned to parent (security by design)
  3. `GET /api/v1/students/me/pending-link` — header: `X-User-Id` (student); returns `{otp, parentName, expiresAt}` only if valid OTP exists; 404 if none/expired
  4. `POST /api/v1/students/link-otp/verify` — body: `{studentEmail, otp}`; validates OTP, calls `clearLinkOtp()`, returns `{studentId, studentName}` for parent-svc link call

**Frontend — ParentChildrenPage.tsx (`LinkChildModal`):**
- Flow: email input → Find (`GET /lookup`) → student preview → Generate OTP → amber notice + countdown → OTP input + relationship → Verify & Link (`POST /link-otp/verify` → `POST /parents/{id}/students`)
- `useEffect` countdown timer (10s poll + 1s tick) — NEVER replace with `useState`
- `useAuthStore` for `parentName` — NEVER use localStorage directly

**Frontend — RegisterPage.tsx Step 4 (PARENT):**
- Same OTP flow inline with `regToken` Bearer auth (axios, NOT api instance)
- State: `childEmail`, `childOtpSent`, `childOtp`, `childOtpExpiresAt`, `childOtpSecondsLeft`, `childOtpError`, `isGeneratingChildOtp`
- `handleChildEmailLookup()` → `handleGenerateChildOtp()` → `handleLinkChildAndFinish()` (verifies OTP + links)
- "Skip for now" → `navigate('/parent')` — ALWAYS present, never remove

**Frontend — SettingsPage.tsx (student ProfileTab):**
- "Parent Link Code" static section REPLACED with "Parent Link Request" dynamic card
- Polls `GET /api/v1/students/me/pending-link` on mount + every 10s via `setInterval`
- Shows big OTP + countdown when parent has generated a request; fallback message when none
- Uses `ShieldCheck` + `Clock` icons; NEVER restore the old `Copy`/`RefreshCw` static code card

**NEVER**:
- Restore the old permanent `parentLinkCode`-based linking flow in any of these 3 frontend files
- Remove the `clearLinkOtp()` call in `verifyLinkOtp()` — the OTP must be single-use
- Change the 300-second expiry in `generateLinkOtp()` — it's a security boundary
- Remove the `link_otp_parent_name` column — the student needs to see who is requesting

---

### Fix #25 — CENTER_ADMIN 403 fix: userId-based center access fallback (commit e91af5e)
**Why frozen**: Kafka is down locally → center_id never written to auth_db users table → JWT carries `centerId=null` → center-svc rejects every CENTER_ADMIN request with 403.

**Root cause**: `AuthPrincipal.belongsToCenter(centerId)` only grants access if `jwt.centerId == targetCenterId`. With null centerId it always denies.

**Fix — `AuthPrincipal.java` (center-svc):**
```java
public boolean belongsToCenter(UUID targetCenterId, UUID centerAdminUserId) {
    if (role == Role.SUPER_ADMIN) return true;
    if (centerId != null && centerId.equals(targetCenterId)) return true;
    // Fallback: grant if this user is the registered admin (centerId not yet synced via Kafka)
    return userId != null && userId.equals(centerAdminUserId);
}
```
Applied in: `CenterService`, `BatchService`, `TeacherService`, `FeeService`, `ContentService`, `TeacherController`.

**NEVER**:
- Remove the `userId == centerAdminUserId` fallback — it's the only access path when Kafka is down locally
- Revert to the single-arg `belongsToCenter(centerId)` call in any of the above services

**Permanent fix (TODO when Kafka is live)**: center-svc should publish `CenterApprovedEvent` on approval; auth-svc consumes it and writes `center_id` to `users` table so the JWT claim is populated.

---

### Fix #26 — Performance-svc + notification-svc bootstrap (commit e91af5e)
**Why frozen**: Both services failed to start due to infrastructure mismatches. Fixes enable local dev without TimescaleDB or manual DB grants.

**Performance-svc — TimescaleDB optional (V1, V5, V6 migrations):**
- `V1__init_schema.sql`: `CREATE EXTENSION timescaledb` wrapped in `DO $$ BEGIN ... EXCEPTION WHEN OTHERS THEN RAISE NOTICE ... END $$` — never fails when timescaledb not installed
- `V5__create_performance_snapshots.sql`: `create_hypertable()` wrapped in `DO $$ IF EXISTS (pg_extension timescaledb) THEN ... END IF $$`
- `V6__create_hypertables.sql`: entire block wrapped in `DO $$` with `pg_extension` existence check at top; returns early if not installed
- **NEVER** make timescaledb required — local PostgreSQL doesn't have it

**Notification-svc — DB permissions:**
- `notification_user` needs `GRANT CREATE ON DATABASE notification_db` + `GRANT USAGE, CREATE ON SCHEMA notification_schema`
- Without this, Flyway V1 fails with `permission denied` and service won't start
- Applied in DB; **document this in local-dev-setup.sh if it's regenerated**

**Student profile seed (qa-test@nexused.dev):**
- `userId`: `50d63f9c-9b9c-4737-a66a-22b29dad42a1` (auth_db — CORRECT value; old memory had wrong UUID)
- `profileId`: `9a70299a-6aee-4f6b-b55e-19e4a9a39f3c`
- `subjects`: `'["Physics","Chemistry","Mathematics"]'::jsonb` — must be `List<String>`, NOT list of objects
- `email_verified`: must be `true` in auth_schema.users or login fails
- **NEVER** insert subjects as `[{"name":..,"code":..}]` — Hibernate maps `List<String>`, objects cause 500

**Captcha bypass format (CRITICAL):**
- Token format: `"{challengeId}:{answer}"` — the bypass token is the challengeId (before colon)
- Correct: `"E2E-LOCAL-BYPASS-DO-NOT-USE-IN-PROD:bypass"`
- Wrong: `"E2E-LOCAL-BYPASS-DO-NOT-USE-IN-PROD"` (no colon → "missing or malformed" error)

---

### Fix #27 — assess-svc V8 migration: pgvector optional for local dev (commit bf89c7c)
**Why frozen**: assess-svc crashed on startup because `V8__activate_pgvector.sql` required the `vector` (pgvector) extension, which is not installed on local vanilla PostgreSQL 16. This caused the exams endpoint (`GET /api/v1/exams?centerId=`) to return 500, showing "Failed to load exams" on the CENTER_ADMIN Assessments page.

**File**: `services/assess-svc/src/main/resources/db/migration/assess/V8__activate_pgvector.sql`

**Fix pattern** (identical to performance-svc V1/V5/V6):
```sql
-- First block: try CREATE EXTENSION, catch gracefully
DO $$
BEGIN
    CREATE EXTENSION IF NOT EXISTS vector SCHEMA assess_schema;
EXCEPTION WHEN OTHERS THEN
    RAISE NOTICE 'pgvector not available — skipping';
    RETURN;
END $$;

-- Second block: only add column + index if extension exists
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_extension WHERE extname = 'vector') THEN
        -- ALTER TABLE ... ADD COLUMN embedding vector(1536)
        -- CREATE INDEX ... USING ivfflat
    END IF;
END $$;
```

**NEVER**:
- Make `CREATE EXTENSION vector` a hard requirement — local PostgreSQL doesn't have pgvector
- Remove the `pg_extension` existence check before adding the `embedding` column or index
- Revert to the bare `CREATE EXTENSION IF NOT EXISTS vector SCHEMA assess_schema;` line — it still throws when the control file is missing

**Pattern applies to all services using optional extensions**: always wrap in `DO $$ EXCEPTION WHEN OTHERS THEN` for the install, and `IF EXISTS (SELECT 1 FROM pg_extension WHERE extname = '...')` for dependent DDL.

---

### Fix #28 — Password Recovery (Section 4.2) — ENTIRE FEATURE
**Why frozen**: Full OTP-based password reset. Removing any part breaks the forgot-password flow.

**Backend — auth-svc:**
- `V5__add_mfa_fields.sql`: adds `mfa_enabled BOOLEAN NOT NULL DEFAULT FALSE`, `totp_secret VARCHAR(64)` to `auth_schema.users`
- `ChangePasswordUseCase` / `PasswordResetUseCase` — new use case ports in `domain/port/in/`
- `ChangePasswordService`: verifies current password, hashes new, calls `tokenStore.deleteAllForUser()` to invalidate all sessions
- `PasswordResetService`:
  - `sendPasswordResetOtp`: silent no-op for unknown email (prevents enumeration); OTP stored under `otp:{email}:PASSWORD_RESET`
  - `verifyPasswordResetOtp`: validates OTP → generates UUID resetToken stored in Redis under `pwd-reset:{email}:{resetToken}` with `resetTokenTtlSeconds` TTL → returns `{resetToken}`
  - `resetPassword`: validates resetToken from Redis, deletes it (single-use), updates password, invalidates sessions
- `AuthController.java`: 4 new endpoints: `POST /change-password` (auth required), `POST /forgot-password` (public, 204), `POST /verify-reset-otp` (public), `POST /reset-password` (public, 204)
- `SecurityConfig`: added `/api/v1/auth/forgot-password`, `/api/v1/auth/verify-reset-otp`, `/api/v1/auth/reset-password` to permitAll
- DTOs: `ChangePasswordRequest`, `ForgotPasswordRequest`, `ResetPasswordRequest`, `PasswordResetOtpVerifyResponse`
- Exceptions: `IncorrectCurrentPasswordException` (422), `InvalidResetTokenException` (410 GONE)
- `GlobalExceptionHandler`: handlers for all new exceptions

**Frontend:**
- `ForgotPasswordPage.tsx` (`/forgot-password`): email form → `POST /api/v1/auth/forgot-password` → always navigates to `/verify-otp` with `{email, purpose: 'PASSWORD_RESET'}` (no enumeration)
- `ResetPasswordPage.tsx` (`/reset-password`): guards missing state; new+confirm password; `POST /api/v1/auth/reset-password`; expired token → redirect to `/forgot-password`
- `OtpPage.tsx`: fixed endpoints (was calling non-existent `/auth/verify-otp` and `/auth/resend-otp`); now branches by purpose: PASSWORD_RESET → `POST /api/v1/auth/verify-reset-otp` → gets resetToken → navigate('/reset-password'); EMAIL_VERIFICATION → `POST /api/v1/otp/verify`; resend → `POST /api/v1/otp/send`
- `router.tsx`: routes for `/forgot-password` and `/reset-password`
- `LoginPage.tsx` "Forgot password?" link goes to `/forgot-password`

**Tests**: `ChangePasswordServiceTest` (3 unit tests), `PasswordResetIT` (4 integration tests), `forgot-password.spec.ts` (5 E2E tests)

**NEVER**:
- Return 404 for unknown email in `forgot-password` — must always return 204 (anti-enumeration)
- Reuse reset tokens — `resetPassword` deletes Redis key immediately after use (single-use)
- Call `/api/v1/auth/verify-otp` or `/api/v1/auth/resend-otp` — these endpoints do not exist

---

### Fix #29 — Two-Factor Authentication/MFA (Section 4.3) — ENTIRE FEATURE
**Why frozen**: Full TOTP-based MFA (RFC 6238). Removing any part breaks secure login and 2FA setup.

**Backend — auth-svc:**
- `pom.xml`: `dev.samstevens.totp:totp-spring-boot-starter:1.7.1` dependency — provides SecretGenerator, CodeVerifier, CodeGenerator, HashingAlgorithm, TimeProvider
- `User.java`: `mfaEnabled` (boolean), `totpSecret` (String) fields; `enableMfa(totpSecret)`, `disableMfa()`, `isMfaEnabled()`, `getTotpSecret()` domain methods — NEVER remove
- `MfaUseCase` port in `domain/port/in/`
- `MfaProperties`: `@ConfigurationProperties(prefix="mfa")` — `issuer`, `pendingTokenTtlSeconds`, `resetTokenTtlSeconds` — all from env vars (`MFA_ISSUER`, `MFA_PENDING_TOKEN_TTL_SECONDS`, `MFA_RESET_TOKEN_TTL_SECONDS`)
- `MfaService`:
  - `initSetup(userId)`: generates secret, stores in Redis `mfa-setup:{userId}` (10 min TTL), returns otpauth:// URI
  - `confirmSetup(userId, totpCode)`: reads pending secret, verifies code, calls `user.enableMfa(secret)`, saves user
  - `disable(userId, totpCode)`: verifies TOTP against stored secret, calls `user.disableMfa()`
  - `verifyLogin(pendingMfaToken, totpCode, deviceFingerprint)`: reads userId from Redis `pending-mfa:{token}`, verifies TOTP, issues full TokenPair
  - `issuePendingMfaToken(userId)`: stores `pending-mfa:{uuid}` → userId in Redis with pendingTokenTtlSeconds TTL
- `AuthenticationService`: MFA gate added — after successful auth, if `user.isMfaEnabled()` throws `MfaRequiredException(pendingToken)` — NEVER remove this gate
- `MfaController`: `GET /api/v1/auth/mfa/status`, `POST /api/v1/auth/mfa/setup`, `POST /api/v1/auth/mfa/setup/confirm`, `DELETE /api/v1/auth/mfa/setup`, `POST /api/v1/auth/mfa/verify` (public)
- `GlobalExceptionHandler`: `MfaRequiredException` → **202 ResponseEntity** with `{mfaRequired:true, pendingMfaToken}` — NOT 4xx/5xx; also handles `InvalidMfaCodeException` (422), `InvalidPendingMfaTokenException` (401), `MfaAlreadyEnabledException` (409), `MfaNotEnabledException` (409)
- `application.yml`: `mfa.issuer`, `mfa.pending-token-ttl-seconds`, `mfa.reset-token-ttl-seconds`
- DTOs: `MfaSetupResponse`, `MfaSetupConfirmRequest`, `MfaVerifyRequest`, `MfaStatusResponse`, `MfaRequiredResponse`
- Exceptions: `MfaRequiredException` (extends RuntimeException, NOT AuthException — important), `InvalidMfaCodeException`, `InvalidPendingMfaTokenException`, `MfaAlreadyEnabledException`, `MfaNotEnabledException`

**Frontend:**
- `package.json`: `"qrcode.react": "^4.2.0"` — QR rendered client-side, secret NEVER sent to external API
- `LoginPage.tsx`: MFA step state (`mfaStep`, `totpCode`, `isMfaSubmitting`); `onSubmit` checks `loginRes.status === 202 && loginRes.data.mfaRequired` (axios doesn't throw on 2xx); `handleMfaVerify` calls `POST /api/v1/auth/mfa/verify`; `finishLogin()` helper extracted
- `SettingsPage.tsx` SecurityTab: real MFA management — `GET /api/v1/auth/mfa/status` on mount; toggle enable → `POST /api/v1/auth/mfa/setup`; confirm → `POST /api/v1/auth/mfa/setup/confirm`; disable → `DELETE /api/v1/auth/mfa/setup`; QR rendered with `<QRCodeSVG value={mfaSetup.qrCodeUri} size={180} />`

**Tests**: `MfaServiceTest` (4 unit tests), `AuthenticationServiceTest` (updated constructor with MfaService mock), `settings-security.spec.ts` (5 E2E tests)

**NEVER**:
- Change `MfaRequiredException` to extend `AuthException` — GlobalExceptionHandler catches it separately to return 202
- Use an external QR image API — client-side `qrcode.react` only (TOTP secret stays in browser)
- Remove the `mfaEnabled` gate in `AuthenticationService` — it's the security boundary for MFA-enrolled users
- Check `loginRes.status === 202` with `response.data.mfaRequired` using axios try/catch — 202 is 2xx, axios does NOT throw; use status check on the resolved response

---

### Fix #30 — Section 3.4 Teacher Onboarding test suite + GlobalExceptionHandler fix (commit 8bd6075)
**Why frozen**: Complete test coverage for the 3.4 Teacher Onboarding feature. Never remove, weaken, or skip these tests. Never revert the GlobalExceptionHandler change.

**Test files (ALL FROZEN — never delete, skip, or weaken assertions):**
- `SubjectCatalogTest.java` (8 tests): resolve exact/alias/case-insensitive, suggest substring, blank/null edge cases
- `TeacherModelTest.java` (12 tests): all 3 factories (create/createInvitationStub/createPending), acceptInvitation/approve/reject state machines + wrong-state `IllegalStateException` guards
- `TeacherBulkImportServiceTest.java` (21 tests): preview validation (email format, duplicate-in-file, already-registered, subject fuzzy match with suggestion, completely unknown subject, missing firstName, quoted CSV, mixed rows), confirm (skip/no-skip), findByToken (valid/expired/unknown), acceptInvitation (valid/invalid/expired token)
- `TeacherApprovalServiceTest.java` (14 tests): selfRegister (success/center-not-found/already-assigned), listPending (admin/super-admin/wrong-admin/empty), approve (success/not-found/wrong-admin/super-admin), reject (success/not-found/wrong-admin)
- `TeacherControllerIT.java` (12 HTTP integration tests): bulk-template download, bulk-preview (valid/invalid email), bulk-confirm (201/400), invitation lookup (200/404), self-register (201/409), pending list, approve→ACTIVE, reject→INACTIVE, accept-invitation (200/400)

**Production fix frozen:**
- `GlobalExceptionHandler.java`: `@ExceptionHandler(IllegalArgumentException.class)` → 400 BAD_REQUEST. **NEVER remove this handler.** Without it, `bulk-confirm` with errors and `skipErrors=false` returns 500 instead of 400, making the error undetectable by the frontend.

**Test patterns (NEVER change):**
- `stubCenter()` helper uses `lenient().when(c.getName())` and `lenient().when(c.getAdminUserId())` — required because these stubs are only consumed by some tests. Removing `lenient()` causes `UnnecessaryStubbingException`.
- `stubCenter()` creates the mock and stubs it BEFORE calling `when(centerRepository.findById(...))` — never inline `mockCenter()` inside `thenReturn()` as it causes `UnfinishedStubbingException`.
- IT tests inject `TeacherRepository` (the domain port) to retrieve invitation tokens after `bulk-confirm` — this is the only way to test the public invitation lookup without exposing tokens in API responses.

---

### Fix #31 — RegisterPage: size, layout, roles, PARENT flow (commit 7356635)
**Why frozen**: User explicitly requested this layout, size, and role structure. NEVER change these values.

**Page size (FROZEN):**
- Outer container: `p-4` (NOT p-6)
- Inner container: `w-full max-w-md` (NOT max-w-lg or max-w-sm)
- Card: `glass rounded-2xl p-4` (NOT the `.card` class which has p-6)
- Logo margin: `mb-5` | Progress bar margin: `mb-5`
- Card min-height: `min-h-[380px]`

**Role dropdown (FROZEN):**
- `type Role = 'STUDENT' | 'PARENT' | 'TEACHER' | 'CENTER_ADMIN'`
- Labels: Student, Parent, Teacher (NOT Mentor), Institution (CENTER_ADMIN)
- CENTER_ADMIN flow: collect institutionName/city/phone inline → register → OTP → POST `/api/v1/centers/self-register` → navigate('/login')
- PARENT flow: Personal Details (step 1) → OTP inline → Link Child inline (Phase C, single-child, skippable)
- NEVER: add a role called "Mentor", show INSTITUTION as separate page redirect, add child slots to the form

**PARENT form (FROZEN):**
- Phase A fields: First Name, Last Name, Email, Password, Confirm Password, Phone Number, Occupation, Captcha
- NO "My Children" section in the form — child linking happens in Phase C (after OTP)
- Phase C: single-child link flow — child email → Find → Generate OTP → OTP entry + relationship → Verify & Link — "Skip for now" always present

**NEVER**: increase container width, add back `.card` class (has p-6), restore "Link Child" as a separate step, add children slots back to the personal details form.

---

### Fix #32 — Settings page: flickering, form reset on refetch, stale saves (commit 3db3717)
**Why frozen**: Three interconnected bugs that together made the Settings profile page unusable. Never revert any of these three changes.

**Bug 1 — Flickering spinner every ~10s (SettingsPage.tsx `ProfileTab`):**
- `fetchPendingLink()` was calling `setPendingLinkLoading(true)` on every background poll
- Caused a brief spinner flash → "No pending link" text toggle every 10 seconds
- Fix: `fetchPendingLink(showSpinner = false)` — only initial mount call uses `showSpinner=true`; interval calls `fetchPendingLink(false)`, skipping loading state

**Bug 2 — /me/pending-link 404 console spam (StudentProfileController + StudentProfileService):**
- When no OTP was active, `getPendingLink()` threw `StudentNotFoundException(null)` → HTTP 404
- Browser logged "Failed to load resource (404)" for every poll (every 10s)
- Fix: service returns `null` when no valid OTP; controller returns `204 No Content` (not 404)
```java
// StudentProfileService
if (!profile.isLinkOtpValid()) {
    return null;  // NOT throw StudentNotFoundException
}
// StudentProfileController
return response != null ? ResponseEntity.ok(response) : ResponseEntity.noContent().build();
```

**Bug 3 — Form edits wiped + saves not reflected (SettingsPage.tsx `ProfileTab`):**
- `useForm` `values` prop resets ALL fields (including user-typed dirty values) whenever React Query refetches `profile` (every 30s staleTime or on window focus)
- After save, Academic Details read-only section showed stale data — query was never invalidated
- Fix 3a: `resetOptions: { keepDirtyValues: true }` on `useForm` — refetch only updates pristine fields
- Fix 3b: `queryClient.invalidateQueries({ queryKey: ['student-profile-me'] })` in `saveMutation.onSuccess`

**NEVER**:
- Remove `resetOptions: { keepDirtyValues: true }` from the `useForm` call in `ProfileTab` — without it, typing in the form is interrupted by background refetches
- Revert `getPendingLink` service to throw `StudentNotFoundException` — it must return `null` for the no-OTP case
- Remove `queryClient.invalidateQueries(['student-profile-me'])` from `saveMutation.onSuccess` — without it, saves don't reflect in the Academic Details section until next refetch cycle
- Call `setPendingLinkLoading(true)` in the interval callback — only the initial mount fetch shows the spinner

---

### Fix #33 — Profile completion % consistent across ALL roles in Settings vs topbar ring (commit 7f42ea8)
**Why frozen**: Settings page showed eternal loading skeleton for PARENT/TEACHER/CENTER_ADMIN (student endpoint returned 404 for non-student userIds). Topbar ring showed correct %. Universal fix — matches ring logic exactly for every role.

**Root cause**: `SettingsPage.tsx` ProfileTab always queried `/api/v1/students/me` regardless of role.

**Fix — `SettingsPage.tsx` ProfileTab:**
- Student profile query: `enabled: !!user && user.role === 'STUDENT'` (was `!!user`)
- Added `parentProfile` query: `queryKey: ['parent-profile']`, `enabled: user.role === 'PARENT'`
- Added `mentorProfile` query: `queryKey: ['mentor-profile-me']`, `enabled: user.role === 'TEACHER'`
- `allFields` / `profilePct` is role-aware — IDENTICAL to AppLayout ring logic:
  - STUDENT(8): `[user.name, user.email, user.avatarUrl, profile.phone, profile.gender, profile.dateOfBirth, profile.city, profile.stream]`
  - PARENT(8): `[parentProfile.name, phone, email, relationshipType, address, city, state, pincode]`
  - TEACHER(7): `[mentorProfile.fullName, email, user.avatarUrl, bio, specializations, yearsOfExperience, hourlyRate]`
  - CENTER_ADMIN/SUPER_ADMIN(3): `[user.name, user.email, user.avatarUrl]`
- `pendingLink` effects guarded: `if (user?.role !== 'STUDENT') return` — no 404 spam for non-students
- Student-specific sections wrapped: Academic Details, Parent Link Request, Edit form — only render for `user.role === 'STUDENT'`

**NEVER**:
- Change the field arrays — they MUST stay identical to AppLayout's per-role arrays or the % will diverge again
- Remove the `user.role === 'STUDENT'` guard from the student profile query — it prevents needless 404s for parents/teachers
- Render Academic Details, Parent Link Request, or the student Edit form for non-STUDENT roles

---

### Fix #34 — Add Child flow for parents (commit 03fca46)
**Replaces** the old OTP-based "Link Child" button in `ParentChildrenPage.tsx` and `ParentDashboardPage.tsx` with a full multi-step "Add Child" modal.

**Key architecture:**
- `POST /api/v1/auth/register-child` (auth-svc, authenticated, no captcha, no OTP): creates ACTIVE student user via `User.createActive()`, returns `{userId, email}`
- Email-check step calls `GET /api/v1/students/lookup?email=` — if found, shows OTP-link suggestion instead of recreating
- Full 3-step modal: personal details (firstName, lastName, email, password + strength indicator, phone, gender, relationship) → academic details (DOB, institutionCode debounced lookup, board, class) → subjects multi-select → done
- Linked via `POST /api/v1/parents/{profileId}/students`
- OTP-link flow for existing students preserved inline

**NEVER:**
- Remove the email-check step — it prevents duplicate student accounts
- Remove the smart detection: if student exists → OTP-link suggestion
- Remove `User.createActive()` factory method (auth-svc) — it bypasses captcha/OTP for parent-authenticated child creation
- Change "Add Child" back to "Link Child"

---

### Fix #35 — Gender fields across all users (commit 03fca46)
**Backend DB migrations:**
- student-profile-svc V8: widens gender column to VARCHAR(20) + `PREFER_NOT_TO_SAY` added to Gender enum
- parent-svc V12: adds `gender TEXT` column to parent_profiles
- mentor-svc V5: adds `gender VARCHAR(20)` column to mentor_profiles

**Backend services:**
- student-profile-svc: `UpdateStudentProfileRequest.gender` (Gender enum) + `StudentProfile.updateGender()` + `StudentProfileService.updateProfile()` applies it
- parent-svc: `UpdateParentProfileRequest.gender`, `ParentProfile.update(gender)`, response includes gender
- mentor-svc: `UpdateMentorProfileRequest` (bio, specializations, yearsOfExperience, hourlyRate, gender) + `UpdateMentorProfileUseCase` + `PATCH /api/v1/mentors/me` endpoint

**Frontend UI:**
- RegisterPage: TEACHER role gets gender dropdown (shared `selectedGender` state); STUDENT + PARENT already had it
- SettingsPage: student edit form has gender select; teacher edit form (new) with bio/specializations/yearsOfExperience/gender saved via `PATCH /api/v1/mentors/me`; profile completion fields updated for parent + teacher to include gender
- ParentProfilePage: gender in view mode (InfoRow) + edit form (select) + profileFields completion
- AppLayout: parent + teacher profile completion arrays include gender

**Profile completion field counts after this fix:**
- STUDENT(8): name, email, avatarUrl, phone, gender, dateOfBirth, city, stream
- PARENT(9): name, phone, email, gender, relationshipType, address, city, state, pincode
- TEACHER(8): fullName, email, avatarUrl, bio, specializations, yearsOfExperience, hourlyRate, gender

**NEVER:**
- Change these arrays without updating BOTH `AppLayout.tsx` AND `SettingsPage.tsx` identically — they MUST stay in sync
- Remove gender from any edit form

---

### Fix #36 — RegisterPage: move STUDENT phone+DOB to step 1, remove Phase C child-link (commit 03fca46)
**Changes:**
- `step1Schema`: added `dateOfBirth: z.string().optional().or(z.literal(''))` — now registered in step 1 form
- `step3Schema`: removed `phone` and `dateOfBirth` fields — academic details only (institutionCode, board, grade)
- Step 1 JSX STUDENT block: 2-column grid Phone (optional) | Date of Birth (required) added after Confirm Password
- `onStep1Submit`: STUDENT guard — if DOB missing → toast error + return; else `calculateAge` + `setIsUnder13` (under-13 parental consent flow unchanged, just triggered at step 1)
- Step 2 (Academic Details) JSX: Phone and DOB inputs removed — form starts with Institution Code
- `onStep3Submit`: removed `calculateAge` + `setIsUnder13` lines (moved to step 1)
- `onSubjectsContinue`: `step3Data.phone` → `step1Data.phone`, `step3Data.dateOfBirth` → `step1Data.dateOfBirth!`
- PARENT `onVerifyOtp` branch: creates parent profile and navigates directly to `/parent` — no Phase C detour

**Removed entirely:**
- `showLinkChild` state and all 13 child-linking state variables (`parentProfileId`, `childEmail`, `childRelationship`, `foundChild`, `childLookupError`, `isLookingUpChild`, `isLinkingChild`, `childOtpSent`, `childOtp`, `childOtpExpiresAt`, `childOtpSecondsLeft`, `childOtpError`, `isGeneratingChildOtp`)
- Child OTP countdown useEffect
- `parentLinkStep` constant
- `handleChildEmailLookup`, `handleGenerateChildOtp`, `handleLinkChildAndFinish` functions
- Phase C JSX block ("Link Your Child" UI)

**Why:** Child linking after parent registration was confusing UX. Parents now go directly to the parent portal dashboard and can add/link children from `ParentChildrenPage.tsx` (the full "Add Child" multi-step flow).

**NEVER:**
- Re-add the Phase C "Link Your Child" block to RegisterPage
- Move DOB back to step 3 for students — it belongs in step 1 (under-13 check needed before OTP)
- Re-add phone/DOB to `step3Schema`

---

### Fix #37 — Test constructors updated for new record fields (commit 04d856a)
Files:
- `services/parent-svc/src/test/java/com/edutech/parent/ParentControllerIT.java`
- `services/parent-svc/src/test/java/com/edutech/parent/ParentProfileIT.java`
- `services/parent-svc/src/test/java/com/edutech/parent/application/service/StudentLinkServiceTest.java`
- `services/student-profile-svc/src/test/java/com/edutech/student/application/service/StudentProfileServiceTest.java`

**Changes:**
- `CreateParentProfileRequest(...)` calls: added `null` as 9th arg for `occupation` field
- `UpdateParentProfileRequest(...)` calls: added `null, null` for `occupation` + `gender` (9th + 10th args)
- `LinkStudentRequest(...)` calls: inserted `null` at position 4 for new `relationship` field; existing args after centerId shift by 1
- `StudentLink.create(...)`: added `null` as 5th arg for `relationship`
- `UpdateStudentProfileRequest(...)` calls: inserted `null` at position 4 for new `gender` field

**Why:** Record fields added in Fix #34 (add-child flow) and Fix #35 (gender fields) broke positional constructor calls in tests. These are the correct arg signatures — NEVER revert to the shorter constructors.

---

### Fix #38 — ParentChildrenPage: remove email-check step from Add Child modal
Commit: `718d5c9`
File: `frontend/web/src/pages/parent/ParentChildrenPage.tsx`

**Changes:**
- Initial step changed from `'email-check'` to `'personal'`
- Removed state: `emailInput`, `looking`, `existingStudent`, `emailChecked`, `otpStep`, `generating`, `otp`, `otpError`, `verifying`, `otpExpiresAt`, `secondsLeft`
- Removed functions: `handleEmailCheck`, `proceedToCreate`, `handleGenerateOtp`, `handleVerifyOtpAndLink`, `fmtTime`
- Removed entire `{step === 'email-check' && (...)}` JSX block (~135 lines) and OTP timer `useEffect`
- Updated `AddChildStep` type: removed `'email-check'`
- Back button on Step 1 changed from `setStep('email-check')` → `onClose`
- Removed unused imports: `Mail`, `Link2`, `StudentLookupResponse` interface

**Why:** User requested "Remove this completely and directly go to next page" — the email-check duplicate-detection screen was an unnecessary first step. Email uniqueness is enforced at API level on submit. Clicking "Add Child" now opens immediately on Step 1 of 3 (Personal Details).

---

### Fix #39 — Add Child modal: DOB to personal step, institution dropdown, AI Smart Find
Commit: `6c45f2d`
File: `frontend/web/src/pages/parent/ParentChildrenPage.tsx`

**Changes:**
1. **DOB moved to Personal Details (Step 1)**: `dateOfBirth` field removed from `AcademicForm`, added to `PersonalForm`. Renders after Confirm Password with calendar icon, optional.
2. **Institution dropdown (Step 2)**: Replaced institution code text input + debounced lookup with `InstitutionSelector` component — fetches `GET /api/v1/centers?size=100`, searchable by name/city, scrollable max-h-48 list.
3. **AI Smart Find tab**: New `ModalMode = 'create' | 'ai-find'` state. Two tabs on modal header. `AISmartFind` component: parent enters child's email → `GET /api/v1/students/lookup?email=` → shows student card (name, class, board, city) → `POST /api/v1/parents/{id}/students` on confirm.

**Why:** User requested (a) DOB in personal step not academic, (b) institution as scrollable select not code input, (c) AI feature to find and link existing students without 3-step create form. NEVER revert these UX decisions or restore the code/debounce input pattern.

---

### Fix #40 — LoginPage: prevent browser autofill pre-filling credentials on refresh
Commits: `ccf4fae`, `b54547a`
File: `frontend/web/src/pages/auth/LoginPage.tsx`

**Changes:**
- Added `autoComplete="off"` to the `<form>` element
- Added `autoComplete="email"` to the email `<input>`
- Added `autoComplete="new-password"` to the password `<input>` (NOT `"current-password"` — that invites autofill)

**Why:** Without `autoComplete` attributes, browsers injected previously entered email+password into the form fields on every page load/refresh (React Hook Form `register()` doesn't set these by default). Users saw stale credentials pre-filled even after logout. `"new-password"` is the correct value — it tells browsers this is NOT a saved-credential login field, so they don't autofill stored passwords.

**NEVER:**
- Change `autoComplete="new-password"` back to `"current-password"` — `"current-password"` actively invites the browser to fill in saved credentials
- Remove `autoComplete="off"` from the form or the per-field attributes
- Restore bare `{...register('email')}` / `{...register('password')}` without autoComplete — causes browser pre-fill on refresh

---

### Fix #41 — JWT expiry detection, inst-registration cleanup, MailHog, build guard (commit f045a38)

**`authStore.ts` + `ProtectedRoute.tsx` — stale session fix (FROZEN):**
- `isJwtExpired(token)`: decodes JWT payload, checks `exp * 1000 < Date.now()` — NEVER remove this helper
- `onRehydrateStorage`: on app startup, if persisted token is expired AND no refreshToken → calls `state.logout()` immediately. Prevents silent 401 loop on every page load after JWT expires.
- `ProtectedRoute`: calls `isJwtExpired(token)` + `logout()` + `<Navigate to="/login">` when token expired with no refresh — prevents broken authenticated pages on stale sessions.
- **NEVER** remove `onRehydrateStorage` from the Zustand persist config — without it, expired sessions persist in localStorage and every protected page hits 401 silently.

**Deleted (institution self-registration — fully removed):**
- `AdminPendingRegistrationsPage.tsx` — deleted
- `RegisterInstitutionPage.tsx` — deleted (CENTER_ADMIN now registers inline on RegisterPage)
- `AdminPortalPage.tsx`: removed `PendingVerificationScreen`, `RejectedScreen`, `pending` tab, import of deleted page
- `router.tsx`: removed `/register-institution` and `/pending-approval` routes
- `center-svc`: deleted `InstitutionRegistrationRequest/Response`, `RegistrationStatusResponse`, `RejectInstitutionRequest` DTOs; deleted `InstitutionAlreadyRegisteredException`, `RegistrationNotFoundException`; cleaned `CenterRepository`, `CenterPersistenceAdapter`, `SpringDataCenterRepository`, `application.yml` of all institution-registration code

**Infrastructure + build (FROZEN):**
- `docker-compose.yml`: MailHog added (`mailhog/mailhog:latest`) — SMTP `:1025`, Web UI `:8025`. NEVER remove — required for password-reset OTP email testing locally.
- `scripts/start-all.sh`: `mvn test-compile` pre-flight before full build — fails fast on test compilation errors. NEVER remove this guard.
- `frontend/web/vite.config.ts`: `host: true` in server block — Vite binds to `0.0.0.0` (IPv4 + IPv6). NEVER remove — without it Vite only binds to IPv6 `[::1]:3000` and `http://localhost:3000` (IPv4) gets `ERR_CONNECTION_REFUSED`. Fixed 2026-03-15.
- `scripts/start-all.sh`: "Useful URLs" footer prints `http://localhost:3000` (was wrongly `5173`). NEVER revert.

**Tests:**
- `MfaServiceTest.java`: `when(valueOps.set(...)).then(inv->null)` → `doNothing().when(valueOps).set(...)` — correct Mockito pattern for void methods on mocks.

---

### Fixes #50–54 — Teacher Registration overhaul + country all roles + district backend (commit 5d86803)

**Fix #50 — Register form autofill blocked**
File: `frontend/web/src/pages/auth/RegisterPage.tsx`
- `<form autoComplete="off">` added to main registration form
- Email input: `autoComplete="new-password"` — blocks Chrome from filling saved credentials
- Both password inputs: `autoComplete="new-password"`
**Why frozen**: Without this, browser fills previous user's email and password into the form on reload.

**Fix #51 — Teacher: Institution dropdown (replaces code text input)**
File: `frontend/web/src/pages/auth/RegisterPage.tsx`
- `teacherInstitutionCode` state + code lookup + `isValidatingTeacherCode` all removed
- Replaced with `teacherCentersList` populated via `GET /api/v1/centers?size=200` on role=TEACHER select
- `<select>` dropdown lets teacher pick from live list; sets `teacherCenterId` + `teacherCenterName`
**Why frozen**: Code-based lookup required knowing a code; dropdown is discoverable.

**Fix #52 — Teacher: Subjects collapsed dropdown**
File: `frontend/web/src/pages/auth/RegisterPage.tsx`
- `teacherSubjectsInput` (string) replaced by `teacherSubjectsArr` (string[]) + `teacherSubjectsOpen` toggle
- Button shows selected subjects as comma-separated; clicking opens scrollable checkbox panel (19 subjects)
- `TEACHER_SUBJECTS` constant defined outside component
- POST sends `teacherSubjectsArr.join(', ')`
**Why frozen**: Comma-separated text was error-prone; dropdown is consistent and discoverable.

**Fix #53 — Country field on all registration roles**
File: `frontend/web/src/pages/auth/RegisterPage.tsx`
- Student: Country after State/City (default "India") — wired to POST `/api/v1/students`
- Parent: Country after Gender (default "India") — wired to POST `/api/v1/parents`
- Teacher: Country in address block (default "India") — UI only (teacher self-register doesn't carry country)
- Institution: Country after State (default "India") — wired to POST `/api/v1/centers/self-register`
**Why frozen**: All roles need country for location completeness.

**Fix #54 — District field: Teacher registration + backend (center-svc + mentor-svc)**
Frontend (`RegisterPage.tsx`): District input in Teacher address block → sent as `district` in teacher self-register POST
Backend center-svc:
- `V12__add_district_to_teachers.sql`: `ALTER TABLE center_schema.teachers ADD COLUMN IF NOT EXISTS district VARCHAR(100)`
- `Teacher.java`: added `district` field, private constructor carries district, `createPending()` 8-arg signature, `getDistrict()`
- `TeacherSelfRegisterRequest.java`: added `@Size(max=100) String district`
- `TeacherApprovalService.java`: passes `req.district()` to `createPending()`, includes in `toResponse()`
- `TeacherResponse.java`: added `String district` field
Backend mentor-svc:
- `V6__add_district_to_mentor_profiles.sql`: `ALTER TABLE mentor_schema.mentor_profiles ADD COLUMN IF NOT EXISTS district VARCHAR(100)`
- `MentorProfile.java`: added `district` field, `getDistrict()`, `update()` gains `district` param
- `UpdateMentorProfileRequest.java`: added `@Size(max=100) String district`
- `MentorProfileResponse.java`: added `String district`
- `MentorProfileService.java`: passes `request.district()` to `update()`, includes `getDistrict()` in `toResponse()`
**Why frozen**: District is a required location field for Indian addresses; stored in DB, surfaced in API responses.

---

### Fix #55 — Staff Portal (CENTER_ADMIN) — Full Role-Based Staff Management + AI
**Feature**: Complete staff management system for CENTER_ADMIN portal.

**Backend files (center-svc)**:
- `V13__add_staff_profile_fields.sql` — 5 nullable columns on `center_schema.teachers`: `role_type VARCHAR(30)`, `qualification VARCHAR(500)`, `years_of_experience INT`, `designation VARCHAR(200)`, `bio TEXT`. Also adds `idx_teachers_center_role_type` index.
- `StaffRoleType.java` — enum: TEACHER, HOD, COORDINATOR, COUNSELOR, LIBRARIAN, LAB_ASSISTANT, SPORTS_COACH, ADMIN_STAFF
- `CreateStaffRequest.java` — record with all staff fields + `@NotNull roleType`, `@Min(0)@Max(60) yearsOfExperience`
- `UpdateStaffRequest.java` — same fields but all nullable (PATCH semantics)
- `StaffService.java` — createStaff (invitation token + TeacherInvitationEvent), updateStaff (PATCH), deactivateStaff (soft delete), reactivateStaff (findById not filtered), listStaff (in-memory filter by roleType + status)
- `StaffController.java` — POST/GET/PATCH/DELETE/POST-reactivate at `/api/v1/centers/{centerId}/staff`
- `Teacher.java` — added 5 new @Column fields + `createStaffInvitation()` factory + `updateProfile()` PATCH method + 5 getters
- `TeacherResponse.java` — added roleType, qualification, yearsOfExperience, designation, bio fields
- `TeacherService.java`, `TeacherApprovalService.java` — `toResponse()` updated to pass new 5 fields
- `TeacherAlreadyAssignedException.java` — added `(String email, UUID centerId)` constructor for email-based duplicate detection
- `TeacherControllerIT.java` — 6 new integration tests (tests 10–15): create staff 201, duplicate 409, PATCH partial update, deactivate, filter by roleType, filter by status

**Frontend files**:
- `staffConstants.ts` — STAFF_ROLE_TYPES (8 roles with color/bg), DESIGNATIONS_BY_ROLE, QUALIFICATION_OPTIONS (22), EXPERIENCE_RANGES (7), STAFF_STATUS_CONFIG, SUBJECT_OPTIONS (17), getStaffRoleConfig()
- `useStaffAI.ts` — `useStaffBioGenerator()` (POST /api/v1/ai/completions, maxTokens:150, temp:0.65) + `useStaffGapAnalysis()` (builds subject coverage map, POST ai/completions, maxTokens:200, temp:0.35)
- `CreateStaffModal.tsx` — 3-step AnimatePresence wizard: Step1=Identity (name/email/phone/employeeId/roleType grid/designation), Step2=Qualifications (subjects tag-picker/yearsExp/district/qualification tag-picker), Step3=AI Polish (preview card + AI Generate bio + bio textarea + Copy + invitation notice)
- `AdminStaffPage.tsx` — sub-tabs (directory/import), stats row (4 counts), role breakdown chips, search+filter bar, staff cards (avatar/role/status badges/chips/bio expandable/deactivate/reactivate), AI Staffing Insights sidebar with Analyse Gaps
- `AdminPortalPage.tsx` — added `'staff'` to TabId union, Staff tab entry (centerAdminOnly:true), UserCog import, AdminStaffPage render
- `AppLayout.tsx` — added UserCog import + Staff nav item to adminNav for CENTER_ADMIN
- `AdminStaffPage.test.tsx` — 5 Vitest unit tests

**Why frozen**: Core CENTER_ADMIN feature. Delivered with full backend+frontend+tests in one session. DB migration V13 already applied to production DB. All 3 screenshots verified live (step1, step3 AI, final directory with staff card).

**How to apply**: ⛔ ASK PERMISSION before ANY change to any staff portal file. Never modify V13 migration.

---

### Fix #56 — Staff Direct ACTIVE Creation (no email invitation) — commit b9e4062
**Change**: Staff are created immediately as ACTIVE — no invitation token, no email, no "Awaiting acceptance" state.

**Backend** (`StaffService.java`):
- Removed invitation token generation (`UUID.randomUUID().toString()`)
- Removed `INVITATION_TOKEN_VALIDITY_DAYS` constant
- Removed `TeacherInvitationEvent` publish
- Removed unused imports (`TeacherInvitationEvent`, `ChronoUnit`)
- Pass `null, null` for token/expiry to `createStaffInvitation()`, then call `staff.reactivate()` immediately

**Frontend** (`AdminStaffPage.tsx`):
- Guard `centerId` before opening modal — `toast.error()` if null (was silently blocking modal)

**Frontend** (`CreateStaffModal.tsx`):
- Renamed "Send Invitation" → "Create Staff", "Sending..." → "Creating..."
- Replaced amber invitation-warning notice with green "Active" notice
- Updated success toast: `"{name} added to staff"` (was `"Invitation sent to {name}"`)

**Also this session** — SUPER_ADMIN user created in DB (`superadmin@nexused.com` / `Test@12345`) and new center created:
- **Sunrise Academy** (centerId: `53e4fa3a-48e8-46bf-9512-7d22d934bee1`, code: `SUNRISE001`, Bengaluru)
- Staff: Anjali Menon (HOD, Mathematics/Physics), Rohan Sharma (TEACHER, Chemistry/Biology) — both ACTIVE

**Why frozen**: User-confirmed working flow. Staff creation verified end-to-end (Priya Sharma, Anjali Menon, Rohan Sharma all created as Active). ⛔ ASK PERMISSION before any change.

---

### Fix #57 — RegisterPage: role dropdown, Country→State→City, email/password at bottom, address line 1+2, board multi-select, pincode (commit e843293)
Files: `frontend/web/src/pages/auth/RegisterPage.tsx`, `frontend/web/src/utils/indiaLocations.ts`

**What was changed:**
- Role selector: native `<select>` dropdown (replaced 2×2 role cards with icons)
- Form field order: role-specific fields first, then Email → Password → Confirm Password at the bottom (before captcha)
- Country defaults to `''` (no pre-selection) for all roles
- All roles: Country (`SearchableSelect`, `WORLD_COUNTRIES`) → State (`SearchableSelect`) → City (`AutocompleteInput` with `getCitiesForState`) — consistent order
- STUDENT: added Pincode field; pincode sent in `POST /api/v1/students` payload
- PARENT: added Address, District, Pincode fields; full payload (address/city/state/district/pincode/country)
- TEACHER: fixed location order → Address → Country → State → City → District
- CENTER_ADMIN: Address split into Line 1 + Line 2; Board → `MultiSelectDropdown` (CBSE/ICSE/STATE_BOARD/IB/IGCSE multi-select); Pincode field; board sent as comma-joined string
- New reusable components in RegisterPage: `SearchableSelect`, `AutocompleteInput`, `MultiSelectDropdown`, `BOARD_OPTIONS`
- `indiaLocations.ts`: added `getCitiesForState()` and `WORLD_COUNTRIES` exports

**Why frozen**: User-confirmed design. ⛔ ASK PERMISSION before any change.

---

### Fix #58 — Staff modal: Subjects hidden for non-teaching roles, District removed (commit 4458d30)
Files: `frontend/web/src/pages/admin/CreateStaffModal.tsx`

**What was changed:**
- `showSubjects` derived flag: `true` only for TEACHER, HOD, COORDINATOR. Hidden for LIBRARIAN, COUNSELOR, LAB_ASSISTANT, SPORTS_COACH, ADMIN_STAFF.
- Subjects section in Step 2 wrapped with `{showSubjects && (...)}` — not rendered for non-teaching roles.
- Submit payload: `subjects: showSubjects && form.subjects.length ? ... : null` — ensures no ghost subjects sent.
- District field fully removed: from `FormState` interface, `INITIAL_FORM`, Step 2 render, and submit payload.
- `MapPin` import removed (was only used for District label).
- Experience (years) now full-width (was half of a 2-column grid with District).

**NEVER**: add subjects back for non-teaching roles. NEVER re-add District to this modal. ⛔ ASK PERMISSION before any change.

---

### Fix #59 — Pre-commit TypeScript hook (commit 4458d30)
File: `.git/hooks/pre-commit`

**What was added:**
- Shell script runs `tsc --noEmit --skipLibCheck` on `frontend/web` before every `git commit`.
- Filters out `.test.ts` / `.test.tsx` errors (vitest types not installed).
- Blocks commit and prints error if any TS errors found in source files.
- `.git/hooks/` is NOT tracked by git — must be re-created manually if repo is cloned fresh.

**NEVER**: remove or disable this hook. It was added to prevent file corruption bugs (e.g., RegisterPage.tsx duplicate tail). ⛔ ASK PERMISSION before any change.

---

### Fix #60 — Jobs feature for institution portal (commit 1b19097)
Files (frontend): `AdminJobsPage.tsx`, `PostJobModal.tsx`, `jobConstants.ts`, `AdminPortalPage.tsx`
Files (backend): `JobPosting.java`, `JobPostingStatus.java`, `JobType.java`, `JobPostingRepository.java`, `JobPostingPersistenceAdapter.java`, `SpringDataJobPostingRepository.java`, `JobPostingService.java`, `JobPostingController.java`, `JobPostingNotFoundException.java`, `CreateJobPostingRequest.java`, `UpdateJobPostingRequest.java`, `StatusUpdateRequest.java`, `JobPostingResponse.java`, `GlobalExceptionHandler.java` (+ 404 handler), `V14__create_job_postings_table.sql`, `V15__add_version_to_job_postings.sql`
Files (gateway): `api-gateway/src/main/resources/application.yml` (added `/api/v1/jobs/**` route)

**What was added:**
- CENTER_ADMIN portal: new "Jobs" tab in AdminPortalPage (centerAdminOnly).
- My Postings sub-tab: stat cards (Total/Open/Draft/Closed+Filled), full CRUD, inline status dropdown (DRAFT→OPEN→CLOSED/FILLED state machine), client-side search + role/status filters, soft-delete.
- Job Board sub-tab: paginated public view of all OPEN postings across all institutions, debounced keyword search, role/jobType dropdowns, city text filter.
- PostJobModal: single-scroll (not wizard), 3 sections — Role & Type (role buttons, job type pills, status), Job Details (title, description, qualifications chips, experience), Compensation & Deadline (salary min/max, deadline date).
- jobConstants.ts: single source of truth — JOB_TYPES, JOB_STATUSES with colors, SUBJECT_ROLES, helper functions (experienceLabel, salaryLabel, deadlineDaysLeft, relativeTime).
- Backend: hexagonal arch — domain model with state machine (publish/close/markFilled/toDraft/softDelete/updateDetails), port interface, Spring Data JPA adapter.
- V14 migration: job_postings table with 3 indexes. V15: added missing `version BIGINT` column for @Version optimistic locking.
- JPQL `CAST(:city AS String)` fix in SpringDataJobPostingRepository.findAllOpen — prevents `lower(bytea) does not exist` error in PostgreSQL when city param is null.
- api-gateway: `/api/v1/jobs/**` route → center-svc (was missing, caused 404 from gateway).

**NEVER**: modify state machine transitions, remove CAST fix, change migration files, remove gateway route. ⛔ ASK PERMISSION before any change.

---

### Fix #61 — Institution Portal E2E + JobPosting IT (commit 7f01c7b)
Files: `frontend/web/tests/e2e/institution-portal.spec.ts`, `services/center-svc/src/test/java/com/edutech/center/JobPostingControllerIT.java`

**What was added:**

**Playwright E2E (22 tests, 5 suites):**
- Suite 1 — Auth & Navigation (3): token injection via localStorage, /admin redirect, 8 tabs visible, unauthenticated redirect.
- Suite 2 — Overview (1): stat cards render.
- Suite 3 — Staff (4): directory sub-tab, import sub-tab, Create Staff button, role filter chips (Teacher/HOD/etc).
- Suite 4 — Jobs My Postings CRUD (8, `test.describe.serial`): heading/stat cards, Post modal (role grid + job type pills), validation stays on modal, create DRAFT, DRAFT→OPEN publish via dropdown, status filter.
- Suite 5 — Jobs Job Board (6): board sub-tab, open positions count text, institution name on card (conditional skip if empty), role/type/city filters.
- Auth strategy: `fetchToken()` calls auth-svc:8182 directly (bypasses captcha with `CAPTCHA_E2E_BYPASS_TOKEN`). `injectAuthAndGo()` sets `localStorage['edupath-auth']` then navigates. `waitUntil: 'load'` (NOT `networkidle` — SSE connections prevent idle).

**Key selector fixes:**
- `getByRole('button', { name: /^Teacher$/i }).last()` — filter pill + modal button both match; `.last()` = modal button.
- `getByRole('button', { name: /^Open$/i }).nth(1)` — filter pill (nth 0), dropdown option (nth 1), existing Open badge (nth 2+).

**Spring IT (17 tests):**
- `JobPostingControllerIT.java` following `CenterControllerIT.java` pattern.
- TestContainers PostgreSQL, `@MockBean JwtTokenValidator + KafkaTemplate`.
- Tests: create (201/DRAFT/403 no-auth/403 wrong-center), list (200), getById (200/404), update (200), status transitions (DRAFT→OPEN/CLOSED/FILLED, invalid→422), delete (204), listJobBoard (OPEN only, roleType filter, city filter, pagination).
- Note: Cannot run locally due to Docker Desktop TestContainers `Status 400` issue (pre-existing macOS limitation affecting all center-svc IT tests). Compiles cleanly from root.

**NEVER**: delete or modify these test files without permission. ⛔ ASK PERMISSION before any change.

---

### Fix #62 — Assignments (RBAC, all roles) + Advertisement Banners (commit d301e53, 2026-03-20)

**assess-svc Assignments:**
- V10: `assess_schema.assignments` (id, batch_id, center_id, created_by_user_id, title, description, type CHECK, due_date, total_marks, passing_marks, instructions, attachment_url, status CHECK, version, timestamps, deleted_at)
- V11: `assess_schema.assignment_submissions` (UNIQUE per assignment+student, status CHECK PENDING→SUBMITTED/LATE→GRADED)
- Domain: `Assignment.java` + `AssignmentSubmission.java` with full state machine methods
- Enums: `AssignmentType` (HOMEWORK/CLASSWORK/PROJECT/QUIZ/PRACTICE), `AssignmentStatus` (DRAFT/PUBLISHED/CLOSED/CANCELLED), `AssignmentSubmissionStatus` (PENDING/SUBMITTED/LATE/GRADED)
- RBAC: SUPER_ADMIN=all, CENTER_ADMIN/TEACHER=own center, STUDENT=published only (submit+view own), PARENT=read published, late detection via `Instant.now().isAfter(dueDate)`
- 12 REST endpoints at `/api/v1/assignments/**` + `/api/v1/students/{id}/assignments`
- `AssignmentControllerIT.java`: 17 tests, TestContainers `pgvector/pgvector:pg16` (required for V8 pgvector migration)

**center-svc Banners:**
- V16: `center_schema.banners` (audience CHECK PARENT/CENTER_ADMIN/ALL, is_active, start_date, end_date, bg_color, display_order, soft-delete)
- JPQL: `ALL` audience matches any query parameter (fully-qualified enum literal in JPQL)
- RBAC: SUPER_ADMIN=full CRUD, any authenticated=read active banners
- `BannerControllerIT.java`: 12 tests, TestContainers postgres:16-alpine

**api-gateway routes added (3 new):**
- `/api/v1/assignments/**` → assess-svc
- `/api/v1/students/*/assignments` → assess-svc
- `/api/v1/banners/**` → center-svc

**Frontend:**
- `StudentAssignmentsPage.tsx` at `/assignments` — tabs All/Pending/Submitted/Graded, submit modal
- `MentorPortalAssignmentsPage.tsx` at `/mentor-portal/assignments` — create/publish/close, grading panel
- `AdminAssignmentsTab.tsx` — admin portal Assignments tab (all roles), SUPER_ADMIN center picker
- `AdminBannersPage.tsx` — SUPER_ADMIN full CRUD, toggle-active
- `AdvertisementBanner.tsx` — hero carousel 180px, auto-rotate `VITE_BANNER_ROTATION_MS` (default 5000ms), pause-on-hover, nav dots, Framer Motion slide
- `FooterBanner.tsx` — 48px strip, fade cycling at 1.5× hero interval, renders null if no banners
- `ParentDashboardPage.tsx` + `AdminDashboardPage.tsx`: both have `<AdvertisementBanner>` at top + `<FooterBanner>` at bottom
- `AdminPortalPage.tsx`: Assignments tab (all roles) + Banners tab (superAdminOnly)
- `AppLayout.tsx`: Assignments nav entry for student/teacher/admin
- `router.tsx`: `/assignments` + `/mentor-portal/assignments` routes

**env var:** `VITE_BANNER_ROTATION_MS` — controls banner auto-rotation interval in ms (default 5000)

**NEVER**: modify any of these files without permission. ⛔ ASK PERMISSION before any change.

---

## Fix #66 — Register dropdown fix + district for all roles (c75c549)

**File:** `frontend/web/src/pages/auth/RegisterPage.tsx`

**Root cause of blink:** `SearchableSelect` and `MultiSelectDropdown` had `onBlur` on the trigger `<button>`. When the dropdown opened, the inner search input's `autoFocus` stole focus from the button → `onBlur` fired → 150ms timer → dropdown closed ("blinked").

**Fix:** Moved `onBlur` to the wrapper `<div>` with `e.currentTarget.contains(e.relatedTarget as Node)` check. Focus staying inside the div (e.g. moving to the search input) no longer triggers close. Only clicking outside does.

**District dropdown added to all 4 registration roles:**
- `STUDENT` — new `SearchableSelect` after City; options = `getDistricts(studentStateVal)`; value sent in student profile POST (`district: studentDistrict || undefined`)
- `PARENT` — replaced plain `<input>` with `SearchableSelect`; options = `getDistricts(parentState)`
- `TEACHER` — replaced plain `<input>` with `SearchableSelect`; options = `getDistricts(teacherStateVal)`
- `INSTITUTION_ADMIN` — new `SearchableSelect` after City; options = `getDistricts(instStateVal)`

**All data from `getDistricts()` in `indiaLocations.ts` — no hardcoded values.**

**NEVER**: remove `relatedTarget` check, revert district dropdowns to plain inputs, or re-add `onBlur` to trigger buttons. ⛔ ASK PERMISSION before any change.

---

## Fix #67 — Universal address fields + correct field order (bd6964e)

**File:** `frontend/web/src/pages/auth/RegisterPage.tsx`

**Address Line 1 + Line 2 added to ALL 4 roles** (was only on INSTITUTION_ADMIN):
- STUDENT: new `studentAddressLine1`, `studentAddressLine2` state; combined in student profile POST as `address`
- PARENT: single "Address" field promoted to Line 1 (`parentAddress`) + Line 2 (`parentAddressLine2`); combined in parent POST
- TEACHER: single "Address" promoted to Line 1 (`teacherAddress`) + Line 2 (`teacherAddressLine2`); `teacherPincode` added
- INSTITUTION_ADMIN: already had L1+L2, no new state needed

**Correct field order enforced for all roles:**
Address Line 1 → Address Line 2 → Country → State → District → City → Pincode

**State onChange now cascades**: clearing District + City when State changes (all roles).

**NEVER**: put City before District, collapse L1+L2 back to a single address field, or remove Pincode from Teacher. ⛔ ASK PERMISSION before any change.

---

### Fix #69 — Comprehensive India location data + pincode auto-fill + register UX (commit bf69e3d)

**India location data (indiaLocations.ts):**
- Replaced hardcoded ~10 districts per state with `india-state-district` npm package (772 districts, all 36 states/UTs)
- `INDIA_STATES` and `DISTRICTS_BY_STATE` now built from `getAllStates()` + `getDistrictsByCode()` at import time
- All existing utility functions preserved (`getDistricts`, `getCitiesForState`, `suggestDistricts`, etc.)
- Added `lookupPincode(pincode)` — calls India Post API (`https://api.postalpincode.in/pincode/{pincode}`), free, no auth, returns `{state, district, city}`

**RegisterPage.tsx fixes:**
- `options={suggestStates('')}` (first 8 only) replaced with `options={INDIA_STATES}` for all state SearchableSelects — all 36 states now searchable
- Pincode auto-fill wired for all 4 roles: entering 6-digit pincode calls `lookupPincode()` → auto-fills State, District, City with a toast notification
- First Name + Last Name hidden until role is selected (gated on `selectedRole && selectedRole !== 'INSTITUTION_ADMIN'`)
- Teacher-role redirect bug fixed: centers fetch useEffect uses plain `axios` (not `api`) — unauthenticated 401 no longer triggers interceptor redirect to /login
- Back button added to Step 1 (navigates to /login); already existed on steps 2/consent/subjects

**NEVER**: revert to hardcoded district data, replace `INDIA_STATES` with `suggestStates('')`, or remove pincode auto-fill. ⛔ ASK PERMISSION before any change.

---

### Fix #70 — INSTITUTION_ADMIN as top self-service role + Jobs/Assignments center picker (commit 2b19f4d)

**Scope**: INSTITUTION_ADMIN is now the fully capable top self-service role, scoped to their own institution.

**Backend (center-svc — BannerService.java / BannerController.java):**
- `BannerService` already had `isSuperAdmin() || isInstitutionAdmin()` guards on all write methods (create, update, toggle, delete, getAllBanners) — this was already correct from Fix #65.
- Updated all Javadoc comments from "SUPER_ADMIN only" → "SUPER_ADMIN or INSTITUTION_ADMIN only".

**Backend (BannerControllerIT.java — 15 tests, was 12):**
- Added 3 INSTITUTION_ADMIN test cases:
  - Test 13: POST /api/v1/banners as INSTITUTION_ADMIN → 201
  - Test 14: GET /api/v1/banners/all as INSTITUTION_ADMIN → 200
  - Test 15: DELETE /api/v1/banners/{id} as INSTITUTION_ADMIN → 204
- `institutionAdminPrincipal` uses `Role.INSTITUTION_ADMIN`, null centerId (no center-specific JWT claim).

**Frontend — AdminJobsPage.tsx:**
- Removed "Centre ID not found" hard error block for admins without a JWT centerId.
- Added `CenterPicker` component: fetches `GET /api/v1/centers?size=100` → renders card list of accessible centres → sets `selectedCenterId` on click.
- `effectiveCenterId = centerId || selectedCenterId` — passed to `MyPostingsTab`. Job Board tab works without any centerId.
- INSTITUTION_ADMIN can now pick one of their centres and manage its job postings.

**Frontend — AdminAssignmentsTab.tsx:**
- Removed `isSuperAdmin` manual UUID input box.
- Added `needsCenterPicker = !centerId` flag (any admin without JWT centerId).
- Fetches centres via `GET /api/v1/centers?size=100` (enabled when `needsCenterPicker`).
- Renders a `<select>` dropdown of accessible centres instead of raw UUID input.
- `effectiveCenterId = centerId ?? selectedCenterId` — query and create button use this value.

**NEVER**: revert to the raw UUID input in AdminAssignmentsTab, re-add "Centre ID not found" error in AdminJobsPage, or restrict banners to SUPER_ADMIN only. ⛔ ASK PERMISSION before any change.

---

### Fix #71 — Profile edit forms for ALL roles (commit b72784e, 2026-03-21)

**Problem**: PARENT had profile data fetched (`GET /api/v1/parents/me`) but NO edit form rendered. CENTER_ADMIN / INSTITUTION_ADMIN / SUPER_ADMIN had NO data fetched and NO edit form.

**SettingsPage.tsx — PARENT edit form (new):**
- State: `parentForm = { name, phone, gender, address, city, state, pincode }` — initialized from `parentProfile` API response on first load (`parentFormInitialized` ref guard prevents re-init on refetch).
- Save: `PATCH /api/v1/parents/me` + (if name changed) `PATCH /api/v1/auth/me` in parallel → updates auth store name.
- Fields rendered: Full Name, Email (read-only), Phone, Gender (select: MALE/FEMALE/OTHER/PREFER_NOT_TO_SAY), Address, City, State (datalist from `suggestStates('')`), Pincode.
- Mutation: `parentSaveMutation` — onSuccess invalidates `['parent-profile']` + updates auth store name.

**SettingsPage.tsx — CENTER_ADMIN / INSTITUTION_ADMIN / SUPER_ADMIN edit form (new):**
- State: `adminForm = { name }` — initialized from `user.name` on first render (`adminFormInitialized` ref guard).
- Save: `PATCH /api/v1/auth/me` with firstName/lastName split from full name → updates auth store.
- Fields rendered: Full Name (editable), Email (read-only).
- Submit button disabled when name is empty.

**AdminDashboardPage.tsx — Welcome greeting fix:**
- Was: `user?.name?.split(' ')[0] ?? 'Admin'` → showed "AI" for institution name "AI Nexus Institute".
- Fixed: `user?.name ?? 'Admin'` — shows full name for admin roles.

**NEVER**: revert PARENT to missing form, remove admin edit form, or re-add `.split(' ')[0]` to admin welcome greeting. ⛔ ASK PERMISSION before any change.

---

### Fix #72 — Notification bell badge dedup (SSE reconnect inflation) (commit b72784e, 2026-03-21)

**Problem**: SSE stream reconnects when the server closes it (backpressure / idle timeout). On reconnect, if the server re-sent any notification, the code did `setUnreadCount((c) => c + 1)` unconditionally — inflating the badge (e.g. 87) while the panel still showed "You're all caught up!" (because the notifications list showed no new items visible, or the count was ahead of real unread).

**Fix — `useNotifications.ts` SSE handler:**
```typescript
setNotifications((prev) => {
  if (prev.some((n) => n.id === incoming.id)) return prev;  // dedup by id
  if (!incoming.readAt) setUnreadCount((c) => c + 1);       // only if genuinely new + unread
  return [incoming, ...prev];
});
```
- Dedup check: if `incoming.id` already exists in the list, return `prev` unchanged (no duplicate, no count increment).
- Count gate: only increment `unreadCount` if the notification is genuinely new AND `readAt` is null/undefined.
- Both `setNotifications` and `setUnreadCount` are inside the same updater function — atomic with React's batching.

**Initial fetch is unaffected** — `fetchNotifications()` still sets `unreadCount = items.filter((n) => !n.readAt).length` from the real API response.

**NEVER**: remove the dedup check (`prev.some(n => n.id === incoming.id)`), unconditionally increment unreadCount on SSE, or call `setUnreadCount((c) => c + 1)` outside the dedup gate. ⛔ ASK PERMISSION before any change.

---

### Fix #73 — Admin profile completion 100% (avatarUrl removed from required fields) (commit dc33618, 2026-03-21)

**Problem**: CENTER_ADMIN / INSTITUTION_ADMIN / SUPER_ADMIN showed 67% profile completion permanently. Root cause traced via `git log --follow`: commit `7f42ea8` introduced `allFields = [user.name, user.email, user.avatarUrl]` for admin roles — 3 fields. `user.avatarUrl` is always `null` for all users (the "Change photo" button shows "Avatar upload coming soon!" toast and never actually saves). With 2/3 fields filled = 67%, with no way to reach 100%.

**Files fixed (MUST stay in sync — Fix #33 rule):**
- `AppLayout.tsx` line ~473: `const f = [!!user.name, !!user.email]` (was `[!!user.name, !!user.email, !!user.avatarUrl]`)
- `SettingsPage.tsx` allFields: `return [user.name, user.email]` (was `[user.name, user.email, user.avatarUrl]`)

**Result**: Admin with name + email filled = 2/2 = **100%**. Ring in topbar and bar in Settings both show 100%.

**Counts after fix**: STUDENT(8), PARENT(9 incl. gender), TEACHER(8 incl. gender), CENTER_ADMIN/INSTITUTION_ADMIN/SUPER_ADMIN(2: name+email).

**NEVER**: add `avatarUrl` back to admin allFields, make the two arrays out of sync, or change admin field count without changing both files simultaneously. ⛔ ASK PERMISSION before any change.

---

### Fix #74 — center-svc stale JAR + pom.xml corruption + E2E login injection pattern (2026-03-21)

**Problem A — center-svc 403 for INSTITUTION_ADMIN**: center-svc JAR was built at 14:27 IST on 2026-03-20, but commit `7f01e5d` (18:15 IST) added `INSTITUTION_ADMIN` to center-svc's `Role` enum. Running JAR didn't have the enum value → `Role.valueOf("INSTITUTION_ADMIN")` threw `IllegalArgumentException` → caught in `JwtTokenValidator.validate()` → `Optional.empty()` → unauthenticated → 403. Fix: rebuild center-svc JAR (`mvn package -pl services/center-svc -am -DskipTests`) and restart.

**Problem B — root pom.xml corrupted**: `pom.xml` had `dumb` prepended before the XML declaration (`dumb<?xml version...`). Fix: removed `dumb` prefix via Edit tool.

**Problem C — E2E browser login injection pattern**: When injecting a JWT into localStorage for Playwright/browser E2E testing, the Zustand persisted state MUST include `isAuthenticated: true`. Without it, Zustand rehydrates with `isAuthenticated: false` (the default) → ProtectedRoute immediately redirects to `/login`. The correct localStorage structure:
```javascript
localStorage.setItem('edupath-auth', JSON.stringify({
  state: {
    token: accessToken,
    refreshToken: null,
    deviceId: 'device-id',
    user: {id: sub, email, role, centerId: null, name: 'Display Name'},
    isAuthenticated: true   // ← CRITICAL — must be true
  },
  version: 0
}));
```

**Problem D — INSTITUTION_ADMIN password**: `AInexus@nexused.com` was registered with an unknown custom password. Reset to `Test@12345` via DB (copied argon2id hash from `ravi.parent@test.com`). SQL: `UPDATE auth_schema.users SET password_hash = '$argon2id$...' WHERE email = 'AInexus@nexused.com'`.

**Centers E2E verified**: INSTITUTION_ADMIN can GET /api/v1/centers (0 results for new user), create center via "Add Center" modal, center appears in list with ACTIVE status. `resolveAccessibleCenters()` correctly scopes to `findByOwnerId(principal.userId())` for INSTITUTION_ADMIN.

**NEVER**: deploy center-svc without rebuilding after any `Role.java` changes. NEVER forget `isAuthenticated: true` in localStorage injection. ⛔ ASK PERMISSION before any code changes.


---

### Fix #76 — VIDEO Banner type (commits ef1b472 + aa2cbd5, 2026-03-21)

**What**: Third `BannerType` enum value `VIDEO` for autoplay muted video advertisements.

**Backend**: `BannerType.VIDEO` added. V18 migration: `ADD COLUMN IF NOT EXISTS video_url TEXT` on `center_schema.banners`. `Banner.java` field `videoUrl` + updated `create()` signature (now 12 params, videoUrl at position 4) + `updateDetails()` (now 11 params, videoUrl at position 4) + getter + setter. `BannerResponse`/`CreateBannerRequest`/`UpdateBannerRequest` all have `String videoUrl`. `BannerService.createBanner()` + `updateBanner()` + `toResponse()` all wire through videoUrl. `BannerControllerIT`: all 15 constructor calls fixed (null inserted for videoUrl).

**Frontend**: `VideoBanner.tsx` (new) at `frontend/web/src/components/ui/VideoBanner.tsx`. Fetches `bannerType=VIDEO` banners. `VideoSlide` sub-component: `<video muted playsInline preload="metadata" poster={imageUrl}>` — **NO `loop` attribute** (loop prevents `onEnded` from firing, breaking cyclic rotation). IntersectionObserver (threshold 0.3, pause when <30% visible), real-time progress bar synced to `timeupdate`, play/pause + mute/unmute hover controls (AnimatePresence fade). Root component: AnimatePresence slide between banners, dot nav. `AdminBannersPage`: VIDEO option in type dropdown, rose-colored badge, Video URL field with amber warning when type=VIDEO and URL empty, `videoUrl` in BannerFormState + API payload. `AdvertisementBanner`: `videoUrl` added to BannerResponse interface (no rendering change — still filters HERO only). Both `AdminDashboardPage` + `ParentDashboardPage`: import + `<VideoBanner audience="…" />` between HERO and Ticker (returns null when no VIDEO banners exist).

**DB constraint fix (V19)**: V18 migration added `video_url TEXT` column but the existing `chk_banner_type` constraint from V17 only allowed `HERO` and `TICKER`. V19 migration (`V19__extend_banner_type_video.sql`) drops and recreates the constraint to include `VIDEO`. Without this, any POST with `bannerType: VIDEO` gets a 23514 `DataIntegrityViolationException` even though the service layer succeeds (banner ID is logged but 500 is returned). Always include V19 when deploying VIDEO banner support.

**FROZEN** ⛔ ASK PERMISSION before any change.

---

### Fix #78 — VIDEO Banner cyclic auto-rotation (commit 08f6182, 2026-03-21)

**What**: VIDEO banners were not cycling between each other automatically.

**Root cause**: `loop` attribute on `<video>` prevents the `onEnded` event from ever firing. The original design relied solely on `onEnded` to advance to the next banner — which never triggered because `loop` restarts the video silently.

**Fix** (`VideoBanner.tsx`):
1. Removed `loop` attribute from `<video>` element in `VideoSlide`.
2. Added `setInterval`-based rotation in the `VideoBanner` main component — same pattern as `AdvertisementBanner` (HERO carousel). Interval reads `VITE_BANNER_ROTATION_MS` env var (default 8000ms). Clears on unmount and when `banners.length <= 1`.
3. `onEnded` still fires for short clips and advances early (dual mechanism).

**⛔ CRITICAL**: NEVER re-add `loop` to the `<video>` element. `loop` silently suppresses `onEnded` — this was the exact root cause of the bug.

**FROZEN** ⛔ ASK PERMISSION before any change.

---

### Fix #79 — Complete institution portal test coverage (commit b7f137f, 2026-03-21)

**What**: Closed all test coverage gaps identified in the institution portal audit.

**BannerControllerIT** (16→20 tests, +4):
- Test 13: `createBanner_withTickerType_succeeds` — TICKER banner persisted with `bannerType=TICKER`
- Test 14: `createBanner_withVideoType_succeeds` — VIDEO banner with `videoUrl` → 201, both fields stored
- Test 15: `updateBanner_changeToVideoType_updatesVideoUrl` — PUT HERO→VIDEO, `videoUrl` atomically updated
- Test 16: `getActiveBanners_videoType_returnedInActiveList` — GET returns VIDEO banner with correct `bannerType` + `videoUrl`

**institution-portal.spec.ts** (22→37 tests, 5→8 suites):
- **Suite 1 fix**: tab count corrected 8→9 (`Assignments` tab was missing from assertion)
- **Suite 6 — Assignments Tab** (4 tests): heading, Create Assignment button, list/empty state, modal opens with title field
- **Suite 7 — Banners Tab (INSTITUTION_ADMIN)** (6 tests): access, Create Banner button, Type column present, Type dropdown has all 3 options (Hero/Ticker/Video), Video URL field appears on VIDEO selection, Banners tab **hidden** for CENTER_ADMIN role
- **Suite 8 — INSTITUTION_ADMIN Role** (5 tests): redirect to /admin, all 10 tabs visible (incl. Banners), Welcome greeting, centre picker shown in Assignments tab (no centerId in JWT), unauthenticated redirect to /login

**Auth helpers updated**: `fetchToken()` and `injectAuthAndGo()` accept optional `user` param (default = CENTER_ADMIN). `INSTITUTION_ADMIN` const: `superadmin@nexused.com` / `Test@12345`, userId `abcb0257-1ca2-43a9-8ac4-a4bb5e02ad39`, no centerId.

**Run**: `CAPTCHA_E2E_BYPASS_TOKEN=E2E-LOCAL-BYPASS-DO-NOT-USE-IN-PROD npx playwright test tests/e2e/institution-portal.spec.ts`

**FROZEN** ⛔ ASK PERMISSION before any change.

---

### Fix #81 — Staff tab CenterPicker for INSTITUTION_ADMIN (commit ba70c91, 2026-03-21)

**What**: `AdminStaffPage` blocked INSTITUTION_ADMIN from using the Staff tab — clicking "+ Create Staff" showed `toast.error('Your account is not linked to a centre…')` because INSTITUTION_ADMIN JWT carries no `centerId`. Same problem existed for Jobs/Assignments (fixed in Fix #70) but Staff was missed.

**Fix** (`frontend/web/src/pages/admin/AdminStaffPage.tsx`):
- Added `CenterPicker` component (same pattern as `AdminJobsPage` Fix #70): fetches `GET /api/v1/centers?size=100`, renders card list, on click sets `selectedCenterId`.
- Added `selectedCenterId` state + `effectiveCenterId = centerId || selectedCenterId`.
- Early return: if `!effectiveCenterId` → render `<CenterPicker onSelect={setSelectedCenterId} />` instead of the full page.
- Removed the `toast.error` guard on the "+ Create Staff" button (no longer needed — CenterPicker ensures `effectiveCenterId` is always set before the button is visible).
- All downstream uses updated: `useQuery` key + `queryFn`, `StaffCard.centerId`, `queryClient.invalidateQueries`, `CreateStaffModal.centerId`.
- Added `Building2` to lucide-react imports.

**Flow for INSTITUTION_ADMIN**: Staff tab → CenterPicker shows owned centres as cards → select one → full Staff Directory loads → Create Staff modal (perfectly centered, all fields visible) → Bulk Import tab (upload zone works).

**⛔ CRITICAL RULES**:
- NEVER revert to the `toast.error` guard on the Create Staff button — it permanently blocked INSTITUTION_ADMIN.
- NEVER pass bare `centerId` (which is null for INSTITUTION_ADMIN) to staff API calls — ALWAYS use `effectiveCenterId`.
- NEVER remove the `if (!effectiveCenterId) return <CenterPicker …/>` gate — without it, API calls fire with `undefined` as the centerId, causing 400/404 errors.
- The same `effectiveCenterId = centerId || selectedCenterId` pattern is used in 3 places (Jobs, Assignments, Staff) — keep them in sync if the pattern ever changes.

**FROZEN** ⛔ ASK PERMISSION before any change.

---

### Fix #80 — AdminBannersPage modal centering + working file upload (commits a41d586 + 569396b, 2026-03-21)

**What**: Two bugs fixed in `AdminBannersPage.tsx` `BannerFormModal`.

**Bug 1 — Modal off-screen (bottom-right instead of centered)**:
Root cause: Framer Motion's `scale`/`y` animation writes inline `style="transform: scale(1) translateY(0px)"` which completely overrides Tailwind's `-translate-x-1/2 -translate-y-1/2` CSS classes. Centering translate was silently lost every time.
Fix: Wrap `motion.div` in `<div className="fixed inset-0 z-[51] flex items-center justify-center pointer-events-none px-4">`. Centering via flexbox — independent of any transform. `pointer-events-none` on outer + `pointer-events-auto` on inner preserves backdrop click. Also uses `createPortal(…, document.body)` to escape any transformed ancestor.
⛔ NEVER use `-translate-x-1/2 -translate-y-1/2` for centering a Framer Motion animated element — flexbox wrapper is the only safe approach.

**Bug 2 — Browse buttons not opening file chooser**:
Root cause: `sr-only` uses `position: absolute` which gets clipped by the parent modal's `overflow-hidden` class, making the hidden input element unclickable.
Fix: Changed `className="sr-only"` → `className="hidden"` (`display: none`). `<label>` wrapping the hidden input still triggers file chooser on click.
Image: `FileReader.readAsDataURL()` → base64 data URL in `imageUrl` (persists in DB). Video: `URL.createObjectURL()` → blob URL in `videoUrl` (browser-session local).
⛔ NEVER use `sr-only` for hidden file inputs inside `overflow-hidden` containers.

**FROZEN** ⛔ ASK PERMISSION before any change.

---

### Fix #82 — Upload zone click-bubble loop fix + INSTITUTION_ADMIN Bulk Import centerId (commit 6b23f51, 2026-03-21)

**What**: File upload zones that used `div + onClick + fileRef.current?.click()` were broken — clicking opened the file chooser then immediately closed it. Also, `AdminBulkImportTeachersPage` silently did nothing for INSTITUTION_ADMIN (centerId null in JWT).

**Root cause — click-bubble loop**:
1. User clicks the `<div>` upload zone → `onClick` fires → calls `fileRef.current?.click()`
2. Programmatic `.click()` on the hidden `<input type="file">` inside the div causes the input to fire its own click event which BUBBLES UP to the parent div
3. The div's `onClick` fires again → calls `.click()` again
4. File chooser opens and immediately closes (double-open / browser cancels the second open)

**Fix** (`AdminBulkImportTeachersPage.tsx`):
- Replaced `<div className="... block" onClick={() => fileRef.current?.click()}>` with `<label className="... block">`
- Hidden `<input type="file">` is now INSIDE the `<label>` — browser natively opens file chooser on label click with no JavaScript, no bubbling
- `fileRef` kept for the `reset()` function (`fileRef.current.value = ''`)
- Added `centerId?: string` prop — `centerId = centerIdProp || storeCenterId` — so INSTITUTION_ADMIN gets `effectiveCenterId` passed from `AdminStaffPage`

**Fix** (`AdminStaffPage.tsx`):
- Pass `centerId={effectiveCenterId}` to `<AdminBulkImportTeachersPage>` (Fix #81 already sets `effectiveCenterId`)

**DOM verification**: `input.parentElement.tagName === 'LABEL'` confirmed in Playwright.

**⛔ UNIVERSAL RULE — FILE UPLOADS**:
- NEVER use `div + onClick + programmatic .click()` for file inputs — causes click-bubble loop
- ALWAYS use `<label>` wrapping `<input type="file" className="hidden">` — native browser behavior, no JS, no bubbling
- This rule applies to ALL upload zones in the entire codebase (AdminBulkImportTeachersPage, AdminBannersPage, any future upload)

**FROZEN** ⛔ ASK PERMISSION before any change.

---

### Fix #83 — TestContainers Docker Desktop 4.60+ API version incompatibility (ALL services)
Commit: `2666427`
Files: `pom.xml`, `services/psych-svc/src/test/resources/application-test.yml`, `services/psych-svc/src/test/resources/testcontainers.properties`

**Root cause**: Docker Desktop 4.60.1 raised `MinAPIVersion` from 1.41 to 1.44. TestContainers bundles (shades) docker-java which hard-defaults to requesting `/v1.41/info`. Docker Engine 29.2.0 returns HTTP 400 for API < 1.44, causing "Could not find a valid Docker environment" for EVERY IT test across ALL services.

**Fix** (`pom.xml`):
```xml
<plugin>
    <artifactId>maven-failsafe-plugin</artifactId>
    <configuration>
        <!-- Docker Desktop 4.60+ raised MinAPIVersion to 1.44 -->
        <argLine>-Dapi.version=1.47</argLine>
    </configuration>
    ...
</plugin>
```
The shaded `DefaultDockerClientConfig` inside TestContainers reads `api.version` from `System.getProperties()`. Passing `-Dapi.version=1.47` via argLine (NOT `-DargLine`, which is wrong) delivers it to the forked Failsafe JVM.

**Fix** (`application-test.yml`):
- Added `spring.datasource.hikari.*` (pool-name, maximum-pool-size=5, minimum-idle=1, connection-timeout=30000, idle-timeout=600000) — `application.yml` uses `${PSYCH_SVC_DB_*}` env vars that are absent in CI/test.
- Added `management.metrics.tags.application: psych-svc-test` and `management.metrics.tags.environment: test` — overrides `${APP_ENVIRONMENT}` and `${PSYCH_SVC_NAME}` placeholders.
- Added `testcontainers.properties` with `docker.client.strategy=UnixSocketClientProviderStrategy` and socket path.

**Result**: All 17 psych-svc IT tests pass (12 PsychControllerIT + 5 PsychAssessmentIT). Fix applies globally to ALL services via root pom.xml.

**⛔ PERMANENT RULES**:
- NEVER remove `<argLine>-Dapi.version=1.47</argLine>` from maven-failsafe-plugin — all IT tests will fail with "Could not find a valid Docker environment".
- NEVER change it to `-DargLine` (command-line override form) in pom.xml — that doesn't work in `<configuration>`.
- NEVER remove the `spring.datasource.hikari.*` block from `application-test.yml` — tests will fail with `NumberFormatException` on pool config.
- NEVER remove `management.metrics.tags.*` from `application-test.yml` — tests will fail with `Could not resolve placeholder 'APP_ENVIRONMENT'`.
- ⛔ ASK PERMISSION before any change to pom.xml failsafe config or psych-svc application-test.yml.

---

### Fix #84 — psych-svc self-service psychometric assessment (null centerId/batchId)
Commit: `2666427`
Files: `PsychProfile.java`, `CreatePsychProfileRequest.java`, `PsychProfileService.java`, `GlobalExceptionHandler.java`, `PsychometricPage.tsx`, `ParentPsychometricPage.tsx`, `PsychAssessmentIT.java`, `PsychControllerIT.java`

**What it does**: Students/parents can create a psychometric profile without belonging to a center or batch (self-service path). Previously `centerId` and `batchId` were required, blocking self-service users.

**Key changes**:
- `CreatePsychProfileRequest`: `centerId` and `batchId` are now `@Nullable`.
- `PsychProfile` domain: constructor accepts null centerId/batchId.
- `PsychProfileService.createProfile`: passes null values through without validation error.
- `GlobalExceptionHandler`: `DataIntegrityViolationException` → HTTP 409 with "A psychometric profile already exists for this person."
- Frontend: both `PsychometricPage.tsx` and `ParentPsychometricPage.tsx` use self-service create flow.
- IT tests: 5 new tests in `PsychAssessmentIT` (createProfile, submitTraitScores, getSessionHistory, listByStudentId, selfService null center/batch).

**⛔ FROZEN** — ASK PERMISSION before any change.

---

### Fix #85 — Part-1 Observability: MDC Correlation IDs + AOP Request Logging + Loki Aggregation + Log Rate-Limiting
Commit: `3288e02`

**Files created (28 new Java files)**:
- 12× `CorrelationIdFilter.java` (servlet `OncePerRequestFilter`, `@Order(HIGHEST_PRECEDENCE)`) — services: auth-svc, center-svc, parent-svc, assess-svc, psych-svc, student-profile-svc, exam-tracker-svc, performance-svc, ai-mentor-svc, career-oracle-svc, mentor-svc, notification-svc. Path: `infrastructure/filter/`
- 3× `CorrelationIdWebFilter.java` (reactive `WebFilter`) — ai-gateway-svc, api-gateway, student-gateway. Path: `infrastructure/filter/`
- 12× `HttpRequestLoggingAspect.java` (servlet `@Aspect @Around @RestController`) — all servlet services. Path: `infrastructure/logging/`
- 1× `HttpRequestLoggingAspect.java` (reactive, ai-gateway-svc) — uses `Mono.doOnSuccess`/`doOnError` hooks instead of try/catch.

**Files modified**:
- `pom.xml` (root): added `<loki4j.version>1.5.2</loki4j.version>` + `loki-logback-appender` managed dep
- 15× service `pom.xml`: added `loki-logback-appender` (all 15) + `spring-boot-starter-aop` (13 servlet services)
- 15× `logback-spring.xml`: `LOKI_URL`/`LOG_DEDUP_REPS`/`LOG_DEDUP_CACHE` springProperties, `DuplicateMessageFilter` TurboFilter, `Loki4jAppender`, updated patterns with `[rid=%X{requestId}] [tid=%X{traceId}]`
- 15× `application.yml`: appended `loki.url` + `log.dedup.*` config blocks
- `.env`: added `LOKI_PORT=3100`, `LOKI_URL=http://localhost:3100`, `LOG_DEDUP_ALLOWED_REPETITIONS=5`, `LOG_DEDUP_CACHE_SIZE=500`
- `infrastructure/monitoring/docker-compose.monitoring.yml`: added `loki` service (grafana/loki:latest, port 3100)

**Files created (monitoring)**:
- `infrastructure/monitoring/loki-config.yaml`: Loki local-dev config (auth disabled, filesystem storage, TSDB schema v13, configurable retention)
- `infrastructure/monitoring/grafana/provisioning/datasources/loki.yaml`: Grafana Loki datasource with `tid=` derived field → Jaeger trace link

**What each gap solves**:
- **Gap 1 — MDC Correlation ID**: Every HTTP request gets a UUID `requestId` (from `X-Request-Id` header or auto-generated). Injected into MDC → appears in every log line automatically via LogstashEncoder. Set on response header too so clients can correlate.
- **Gap 2 — Loki log aggregation**: All services push structured logs to Grafana Loki over HTTP via `loki4j-logback-appender`. Grafana can query `{service="auth-svc"}` + filter by `requestId`, `traceId`, `level`.
- **Gap 3 — Distributed tracing**: Was already complete (micrometer-tracing-bridge-otel). Logback pattern now exposes `traceId` as `[tid=...]` in all service logs.
- **Gap 4 — AOP controller logging**: Every `@RestController` method logs `→ method`, `← method duration=Xms`, `✗ method failed error=...` without touching any controller. Zero boilerplate added to controllers.
- **Gap 5 — Log rate-limiting**: `DuplicateMessageFilter` prevents log flooding. After `${LOG_DEDUP_ALLOWED_REPETITIONS}` identical messages, further repeats are suppressed. Cache size configurable.

**Lombok fix**: All `HttpRequestLoggingAspect.java` files use explicit `LoggerFactory.getLogger()` — NOT `@Slf4j` (Lombok not configured as annotation processor in these services).

**⛔ PERMANENT RULES**:
- NEVER use `@Slf4j` in new `infrastructure/logging/` or `infrastructure/filter/` classes — Lombok annotation processor is NOT in `<annotationProcessorPaths>` for these services. Use `LoggerFactory.getLogger(Foo.class)` directly.
- NEVER remove the `DuplicateMessageFilter` TurboFilter from any `logback-spring.xml` — it prevents log storms during high traffic.
- NEVER remove the `LOKI` appender-ref from either `<springProfile>` block — logs would stop flowing to Loki.
- NEVER remove `loki.url` or `log.dedup.*` from `application.yml` — Logback springProperty fails silently, defaults kick in but env var override breaks.
- NEVER remove `CorrelationIdFilter`/`CorrelationIdWebFilter` — requestId MDC key disappears from all logs.
- NEVER remove `HttpRequestLoggingAspect` — AOP controller entry/exit/error logging disappears platform-wide.
- ⛔ ASK PERMISSION before any change to any of the 28 new Java files, 15 logback configs, or monitoring stack.

---

### Fix #86 — Student Settings page: create profile on first save instead of PATCH (commit 9e9ddbc, 2026-03-22)

**Root cause**: `saveMutation` in `SettingsPage.tsx` always called `PATCH /api/v1/students/me`. Brand-new students (no row in `student_profile_db`) get 404 on PATCH. Also the student profile query had no `retry:false` so 404 spammed 3 retries.

**Files**: `frontend/web/src/pages/settings/SettingsPage.tsx`

**Fix**:
- If `!profile` (no profile row exists yet): call `POST /api/v1/students` with `userId`, `email` from auth store, `firstName`/`lastName` from form, `dateOfBirth: '2000-01-01'` as placeholder (student updates later).
- If `profile` exists: keep calling `PATCH /api/v1/students/me` as before.
- Added `retry: false` + `throwOnError: false` to the student profile query — 404 is expected for new students, must not retry or crash the page.

**⛔ NEVER** make `saveMutation` always PATCH — it must detect create vs update by checking `!profile`. **⛔ ASK PERMISSION** before any change.

---

### Fix #87 — AppLayout student profile ring shows 0% for new users with no profile row (commit 78fb9a5, 2026-03-22)

**Root cause**: `AppLayout.tsx` line 470 initialises `let profilePct = 0`. The STUDENT branch was `if (user.role === 'STUDENT' && studentProfile)` — when `studentProfile` is `undefined` (new student, 404), the condition is false, the block is skipped, `profilePct` stays 0. Ring shows 0% instead of the correct partial completion.

**Why it was never caught before**: All previous test students had pre-seeded profile rows in `student_profile_db`. `ram@nexused.com` was the first real brand-new student using the app from zero state.

**Files**: `frontend/web/src/components/layout/AppLayout.tsx`

**Fix**:
- Changed `if (user.role === 'STUDENT' && studentProfile)` → `if (user.role === 'STUDENT')` — always enter the STUDENT branch.
- Used optional chaining: `studentProfile?.phone`, `studentProfile?.gender`, etc. — safely resolves to `undefined` when profile row doesn't exist.
- Result: new student with only `name` + `email` = 2/8 = **25%** (correct). Profile fields populate as student fills them in.
- Added `retry: false` + `throwOnError: false` to AppLayout's student profile query (same as SettingsPage Fix #86).

**⛔ PERMANENT RULES**:
- NEVER put `&& studentProfile` back in the STUDENT profilePct branch — 0% for new users is wrong.
- NEVER remove the optional chaining (`?.`) on studentProfile fields — crashes for new users.
- ALWAYS apply `retry: false + throwOnError: false` to ANY query that fetches a profile that may not exist yet (student, parent, mentor). 404 = "not created yet", not an error.
- **The 8-field array stays**: `[user.name, user.email, user.avatarUrl, studentProfile?.phone, studentProfile?.gender, studentProfile?.dateOfBirth, studentProfile?.city, studentProfile?.stream]` — same as Fix #33/#35 but with optional chaining.
- AppLayout and SettingsPage `allFields` arrays MUST stay in sync (Fix #33 rule).
- ⛔ ASK PERMISSION before any change.

---

### Fix #88 — E2E student onboarding spec: structural CI guard for zero-state new-user bugs (2026-03-22)

**Root cause prevented**: Fixes #86 and #87 were triggered by `ram@nexused.com` — the first truly brand-new student ever to use the app. All previous test accounts had pre-seeded `student_profile_db` rows. Memory/CLAUDE.md/pre-commit hooks protect against regression of *known* fixes but cannot catch *untested* new-user zero-state flows.

**File**: `frontend/web/tests/e2e/student-onboarding.spec.ts`

**Coverage (5 tests, 2 suites)**:
- Suite 1 — registers a fresh student via auth-svc API, reads OTP from MailHog, verifies, injects JWT, navigates to /settings:
  1. Profile tab renders without crashing (no "Something went wrong")
  2. First save calls POST /api/v1/students (create), NOT PATCH — directly tests Fix #86
  3. Profile completion ring shows > 0% — directly tests Fix #87
  4. Second save (profile now exists) calls PATCH, not POST — regression guard for the correct update path
- Suite 2 — logs in as an existing pre-seeded student and confirms PATCH still works (no regression of the happy path)

**Auth strategy**: API-level registration + MailHog OTP polling + localStorage token injection (same pattern as institution-portal.spec.ts — avoids live captcha overhead, fast and deterministic).

**Run command**:
```bash
CAPTCHA_E2E_BYPASS_TOKEN=E2E-LOCAL-BYPASS-DO-NOT-USE-IN-PROD npx playwright test tests/e2e/student-onboarding.spec.ts
```

**⛔ PERMANENT RULES**:
- NEVER remove or skip this spec — it is the only CI guard against zero-state new-user profile bugs.
- NEVER change Suite 1 test 2 assertion (`createCalled === true && patchCalled === false`) — that is the exact regression test for Fix #86.
- NEVER change Suite 1 test 3 ring assertion (`pct > 0`) — that is the exact regression test for Fix #87.
- NEVER change Suite 2 assertion (`patchCalled === true`) — regression guard for existing-user PATCH path.
- ⛔ ASK PERMISSION before any change to this file.

---

### Fix #89 — Profile completion skeleton for PARENT/TEACHER across ring + bar + backend (commit 6e91249, 2026-03-22)

**Root cause (3 independent bugs, all born in different commits, all missed by Fix #87):**

1. **AppLayout.tsx ring 0% for PARENT** (born `858bbcf`): `&& parentProfile` guard → ring stays 0 while query is in-flight or 404.
2. **AppLayout.tsx ring 0% for TEACHER** (born `8822dfa`): `&& mentorProfile` guard → same.
3. **SettingsPage.tsx bar skeleton for STUDENT** (born `7f42ea8`, missed by Fix #86/87): `&& profile` in `allFields` IIFE → `profilePct = null` → `animate-pulse` skeleton shown. Fix #86 added `retry:false` to the query but left the guard intact.
4. **SettingsPage.tsx bar skeleton for PARENT** (born `7f42ea8`): `&& parentProfile` in `allFields` IIFE → skeleton.
5. **SettingsPage.tsx bar skeleton for TEACHER** (born `7f42ea8`): `&& mentorProfile` in `allFields` IIFE → skeleton.
6. **`PATCH /api/v1/parents/me` missing** (born `b72784e`, Fix #71): Frontend calls this endpoint but it was never implemented in `ParentController`. Every parent Save → 404 since Fix #71.
7. **Teacher with no mentor_profile row → 404 on PATCH**: `PATCH /api/v1/mentors/me` → `MentorNotFoundException` if no row exists.

**Files changed:**

*Frontend — `AppLayout.tsx`*:
- parentProfile + mentorProfile queries: added `retry:false + throwOnError:false`
- PARENT branch: `&& parentProfile` removed → `parentProfile?.name` optional chaining on all 9 fields
- TEACHER branch: `&& mentorProfile` removed → `mentorProfile?.fullName` optional chaining on all 8 fields

*Frontend — `SettingsPage.tsx`*:
- parentProfile + mentorProfile queries: added `retry:false + throwOnError:false`
- `allFields` IIFE: removed `&& profile`, `&& parentProfile`, `&& mentorProfile` guards; all fields use `?.` optional chaining
- `parentSaveMutation`: `!parentProfile` → `POST /api/v1/parents` (create, includes `email: user.email`); else `PATCH /api/v1/parents/me` (update)
- `teacherSaveMutation`: `!mentorProfile` → `POST /api/v1/mentors` (create, includes `userId`, `fullName`, `email`, `hourlyRate:0.01` minimum); else `PATCH /api/v1/mentors/me` (update)

*Backend — `parent-svc`*:
- `UpdateParentProfileUseCase.java`: added `updateMyProfile(request, principal)` to port interface
- `ParentProfileService.java`: implemented — `findByUserId(principal.userId())` → `profile.update(...)` → save (mirrors mentor-svc pattern)
- `ParentController.java`: added `@PatchMapping("/me")` → `PATCH /api/v1/parents/me` now exists

**⛔ PERMANENT RULES**:
- NEVER restore `&& parentProfile` or `&& mentorProfile` guards in AppLayout or SettingsPage.
- NEVER restore `&& profile` in SettingsPage `allFields` for STUDENT.
- ALWAYS use `?.` optional chaining on profile fields for STUDENT/PARENT/TEACHER — profile row may not exist for new users.
- NEVER make parentSaveMutation or teacherSaveMutation always PATCH — must detect `!profile` → create first.
- NEVER remove `PATCH /api/v1/parents/me` from ParentController or `updateMyProfile` from the service/port.
- ALL profile queries (student/parent/mentor) in AppLayout AND SettingsPage MUST have `retry:false + throwOnError:false` — 404 = no row yet, not an error.
- parent-svc requires rebuild + restart after this commit for the new endpoint to be live.
- ⛔ ASK PERMISSION before any change.

---

### Fix #90 — Job Board for STUDENT / PARENT / TEACHER (commit 93703a4, 2026-03-22)

`JobBoardPage.tsx` — read-only paginated job board at `/jobs` (student), `/parent/jobs` (parent), `/mentor-portal/jobs` (teacher). Calls `GET /api/v1/jobs`. Filters: roleType, jobType, city, keyword (400ms debounce). Size=20 pagination. Briefcase "Job Board" nav item added to studentNav, parentNav, mentorNav in AppLayout.tsx. Routes added to router.tsx. JWT decoded from token — no hardcoded IDs. 14 E2E tests (3 suites) in `job-board.spec.ts`.

**⛔ PERMANENT RULES**:
- NEVER add admin write controls (Post a Job / status change) to JobBoardPage — it is read-only by design.
- Nav items in AppLayout.tsx (Briefcase / Job Board) for all 3 non-admin roles are FROZEN.
- ⛔ ASK PERMISSION before any change.

---

### Fix #91 — GitHub OAuth sign-in + social buttons always visible (commit fdb565e, 2026-03-23)

**GitHub OAuth backend (auth-svc)**:
- `GitHubOAuthService.java` — full OAuth2 code exchange: POST `https://github.com/login/oauth/access_token` (form-encoded, Accept: application/json) → GET `https://api.github.com/user` (Bearer + vnd.github.v3+json). GitHub `id` is long → `String.valueOf()`. Email null/private → `login@users.noreply.github.com` fallback. Display name null → split by space; fallback firstName=login, lastName="". Find-or-create (provider=GITHUB) → linkOAuthProvider if found by email. Issues JWT via TokenService. Throws `GitHubOAuthDisabledException` (→ 400) when `client-id` or `client-secret` blank.
- `GitHubAuthRequest.java` — `record GitHubAuthRequest(@NotBlank String code, String role)`. Frontend sends `code` (not access_token) — server does the exchange.
- `AuthController.java` — added `GitHubOAuthService` field + constructor injection + `POST /api/v1/auth/github` endpoint.
- `SecurityConfig.java` — `/api/v1/auth/github` added to public POST `permitAll` list (same position as `/api/v1/auth/google`).
- `application.yml` — `github.client-id: ${GITHUB_OAUTH2_CLIENT_ID:}` + `github.client-secret: ${GITHUB_OAUTH2_CLIENT_SECRET:}` (no defaults — blank = disabled, no error at startup).

**Frontend — `LoginPage.tsx`**:
- Google + GitHub buttons **always rendered** regardless of env vars (removed `hasSocial` guard + `{hasSocial && ...}` wrapper).
- Google: `VITE_GOOGLE_CLIENT_ID` set → real `<GoogleSignInButton>`; unset → look-alike fallback `<button>` with Google SVG that fires `toast.info('Google Sign-In is not configured...')`.
- GitHub: `initiateGithubLogin()` checks `!GITHUB_CLIENT_ID` first → `toast.info(...)` and return (no redirect to malformed URL). Button always rendered.
- Grid always `grid-cols-2` — both providers side-by-side at all times.
- Divider "or sign in with email" always visible.

**E2E — `login-page-showcase.spec.ts`**:
- Suite 3 rewritten from "buttons absent" to "buttons always visible" (3 tests: GitHub visible, Google visible, divider visible).
- 17/17 tests pass.

**No hardcoded values**:
- All OAuth credentials via env vars: `GITHUB_OAUTH2_CLIENT_ID`, `GITHUB_OAUTH2_CLIENT_SECRET`, `VITE_GITHUB_CLIENT_ID`, `VITE_GOOGLE_CLIENT_ID`.
- GitHub/Google API URLs are public constants (not runtime-configurable — correct by design).
- All role routing in `handleGithubCallback` / `handleGoogleSuccess` follows existing pattern (reads `u.role` from `/api/v1/auth/me`).

**To enable in production**: add to `.env`:
- `GITHUB_OAUTH2_CLIENT_ID=<app_client_id>`
- `GITHUB_OAUTH2_CLIENT_SECRET=<app_client_secret>`
- `VITE_GITHUB_CLIENT_ID=<app_client_id>`  (Vite build-time)
- Rebuild auth-svc + Vite frontend after adding env vars.

**⛔ PERMANENT RULES**:
- NEVER add `loop` to any `<video>` element (suppresses `onEnded`, breaks cyclic rotation — see Fix #76).
- NEVER wrap social buttons in a conditional that hides them when env vars are absent. They are always rendered.
- NEVER use a plain string (not JSON object) for `deviceFingerprint`.
- NEVER call `POST /api/v1/auth/github` with `{ accessToken }` — the contract is `{ code }` (server-side exchange).
- `GitHubOAuthService` and `GoogleOAuthService` must remain structurally parallel (same `@Transactional`, `DeviceFingerprint` pattern, `linkOAuthProvider` fallback).
- `GoogleSignInButton` MUST remain guarded by `VITE_GOOGLE_CLIENT_ID` — rendering it without a valid `clientId` crashes the `useGoogleLogin` hook from `@react-oauth/google`.
- ⛔ ASK PERMISSION before any change.

---

### Fix #94 — Permanent login fix: stale token interceptor + stale CAPTCHA (commit 4bf1131, 2026-03-23)

**Root cause**: Three compounding bugs caused login to fail after any JWT expiry:

1. **`api.ts` request interceptor** injected the stored token unconditionally (`if (token) set header`). An expired token in localStorage was injected into the `GET /api/v1/auth/me` call that happens immediately after a successful login POST — overwriting the fresh token explicitly passed to that call → 403.

2. **`authStore.ts` `onRehydrateStorage`** — previous logic only called `state.logout()` if there was NO refresh token. If a refresh token was present, the expired access token was left in the store untouched. The interceptor then injected it on every request.

3. **`LoginPage.tsx` stale CAPTCHA** — after a failed login, `setCaptchaToken(null)` reset the value but `CaptchaWidget` was not remounted. It kept the same Redis challenge ID → the same "E2E----" stale token appeared on every retry.

**Fixes**:
- `frontend/web/src/lib/api.ts`: interceptor now skips token injection when `isJwtExpired(token)` is true:
  `if (token && !isJwtExpired(token)) config.headers.Authorization = \`Bearer ${token}\`;`
- `frontend/web/src/stores/authStore.ts`: `onRehydrateStorage` now always clears stale access token:
  expired + refresh token present → `state.setTokens('', state.refreshToken)` (not logout)
- `frontend/web/src/pages/auth/LoginPage.tsx`: `captchaKey` state increments on every failed login → `key={captchaKey}` on `<CaptchaWidget>` forces remount → fresh Redis challenge every retry.

**⛔ PERMANENT RULES**:
- NEVER remove the `!isJwtExpired(token)` guard from `api.ts` interceptor.
- NEVER revert `onRehydrateStorage` to only calling `logout()` — must always clear stale access token when refresh token exists.
- NEVER remove `key={captchaKey}` from `<CaptchaWidget>` or the `setCaptchaKey((k) => k + 1)` in the login catch block.
- ⛔ ASK PERMISSION before any change.

---

### Fix #95 — Modal centering + centerType-aware labels for Jobs and Staff (commit c321fd8, 2026-03-23)

**Modal centering — `MentorPortalAssignmentsPage.tsx`**:
- `CreateAssignmentModal` and `GradeModal` both used `fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2` on a `motion.div` — Framer Motion's internal `transform` overrides Tailwind translate, pushing the modal below the viewport.
- Fix: `createPortal(…, document.body)` + flexbox wrapper `fixed inset-0 z-[51] flex items-center justify-center pointer-events-none` around `motion.div pointer-events-auto w-full max-w-lg`. GradeModal uses `z-[60]/z-[61]`, `max-w-md`.
- ⛔ NEVER use `-translate-x-1/2 -translate-y-1/2` on any `motion.div` — Framer Motion overrides it. ALWAYS use createPortal + flexbox centering wrapper.

**CenterType-aware labels — `AdminJobsPage.tsx`**:
- Fetches `GET /api/v1/centers/${effectiveCenterId}` → `centerInfo.centerType`.
- `isSchoolOrCollege = centerType === 'SCHOOL' || centerType === 'COLLEGE'`.
- `MyPostingsTab` subtitle and CenterPicker text adapt per centerType. Passed as `<MyPostingsTab centerType={centerType} />` prop.

**CenterType-aware labels — `AdminStaffPage.tsx`**:
- Same `centerInfo` query pattern. Heading: school/college → "Staff & Faculty". Subtitle adapts per type.

**CenterType values** (set at center creation in AdminCentersPage 3-button selector or INSTITUTION_ADMIN RegisterPage):
- `COACHING_CENTER` | `SCHOOL` | `COLLEGE`
- Stored in `center_schema.coaching_centers.center_type`, returned in `GET /api/v1/centers/{id}` as `centerType`.

**⛔ PERMANENT RULES**:
- NEVER add `-translate-x/y-1/2` back to modal `motion.div` elements — use createPortal + flexbox.
- NEVER hardcode center type labels — always derive from `centerInfo.centerType`.
- ⛔ ASK PERMISSION before any change.

---

### Temp — Job Board nav disabled for PARENT and TEACHER (commit e384b9b, 2026-03-23)

Temporary, not a permanent freeze. `AppLayout.tsx` `parentNav` and `mentorNav` Job Board entries have `disabled: true`. The `NavItem` interface has `disabled?: boolean`. Disabled items render as a non-clickable `<span>` (text-white/20, cursor-not-allowed). Route, page, and all code untouched. To re-enable: remove `disabled: true` from lines for `/parent/jobs` and `/mentor-portal/jobs` in `AppLayout.tsx`.

---

### Fix #96 — Remove marks from assignments + auto-open create for school/college (commit 4895229, 2026-03-23)

**Assignments — total/passing marks removed (frontend + backend)**:

Backend:
- `CreateAssignmentRequest.java`: `double totalMarks/passingMarks` → `Double` (nullable); removed `@DecimalMin` constraints. Import of `DecimalMin` removed.
- `AssignmentResponse.java`: `double` → `Double` for both fields.
- `UpdateAssignmentRequest.java`: `double` → `Double` for both fields.
- `Assignment.java`: column annotations changed from `nullable = false` → nullable (no annotation); field types `double` → `Double`; `create()` factory + `updateDetails()` signatures updated to accept `Double`; `updateDetails()` null-guards changed from `> 0` / `>= 0` to `!= null`; getters return `Double`.
- `V12__make_assignment_marks_nullable.sql`: `ALTER TABLE assess_schema.assignments ALTER COLUMN total_marks DROP NOT NULL; ALTER TABLE assess_schema.assignments ALTER COLUMN passing_marks DROP NOT NULL;` — run on next assess-svc restart.

Frontend:
- `MentorPortalAssignmentsPage.tsx`: removed `totalMarks`/`passingMarks` from `CreateAssignmentRequest` interface; removed from form state init (`totalMarks:100, passingMarks:40` gone); removed the disabled "Total Marks / Passing Marks" grid div from modal JSX; `GradeModal` prop `totalMarks: number` → `totalMarks?: number`; `AssignmentResponse` fields made optional (`totalMarks?`, `passingMarks?`).
- `AdminAssignmentsTab.tsx`: `AssignmentResponse.totalMarks`/`passingMarks` made optional.

**⛔ PERMANENT RULES**:
- NEVER add total/passing marks back to the Create Assignment form — they are removed by design.
- NEVER make `totalMarks`/`passingMarks` required again in `CreateAssignmentRequest` or `Assignment.create()`.
- NEVER remove V12 migration or restore the NOT NULL constraints on those columns.
- Requires assess-svc rebuild + restart for V12 migration to run.

**Jobs / Staff / Library — auto-open create for SCHOOL/COLLEGE**:

Pattern used in all three pages:
```typescript
const autoOpenedRef = useRef(false);
useEffect(() => {
  if (!autoOpenedRef.current && isSchoolOrCollege && effectiveCenterId) {
    autoOpenedRef.current = true;
    setShow<Modal>(true);
  }
}, [isSchoolOrCollege, effectiveCenterId]);
```
- `useRef` ensures modal opens exactly once per component mount (tab visit). Re-visiting the tab remounts the component → ref resets → modal opens again.
- COACHING_CENTER: `isSchoolOrCollege` remains false → no auto-open → existing listing behaviour.
- `AdminJobsPage` (`MyPostingsTab`): auto-opens `PostJobModal` (`setShowModal`). `useRef`/`useEffect` already imported at file level.
- `AdminStaffPage`: auto-opens `CreateStaffModal` (`setShowCreate`). Added `useRef, useEffect` to imports.
- `AdminLibraryPage`: added `centerInfo` query + `isSchoolOrCollege` derivation; auto-opens `UploadWizard` (`setShowUpload`). Added `useEffect` to imports.

**⛔ PERMANENT RULES**:
- NEVER hardcode centerType checks — always derive `isSchoolOrCollege` from fetched `centerInfo.centerType`.
- NEVER skip the `autoOpenedRef` guard — without it the modal re-opens on every re-render.
- NEVER make auto-open fire for COACHING_CENTER — only SCHOOL/COLLEGE.
- ⛔ ASK PERMISSION before any change.

---

### Fix #97 — Auto-bypass CenterPicker for SCHOOL/COLLEGE in Jobs, Staff, Library (e4122fe)

INSTITUTION_ADMIN (and any role without `centerId` in JWT) previously saw a CenterPicker card list before accessing Jobs, Staff, or Library tabs. For SCHOOL/COLLEGE centers this was unnecessary friction. Fix: after centers are fetched, if **all** centers are non-COACHING_CENTER → auto-select `centers[0].id`, show spinner during transition, skip picker UI entirely. COACHING_CENTER unchanged.

**Pattern used in all 3 files:**
- `CenterOption`/`CenterResponse` interface: added `centerType?: string`
- `allSchoolOrCollege = centers.length > 0 && centers.every(c => c.centerType !== 'COACHING_CENTER')`
- `useEffect`: calls `onSelect(centers[0].id)` when `allSchoolOrCollege` is true
- Return spinner when `isLoading || allSchoolOrCollege` (no picker flash)

**AdminJobsPage.tsx + AdminStaffPage.tsx**: logic lives inside `CenterPicker` component (centers fetched internally).
**AdminLibraryPage.tsx**: logic lives in main component (centers fetched externally and passed to CenterPicker).

**⛔ PERMANENT RULES**:
- NEVER show CenterPicker for SCHOOL/COLLEGE — auto-select first center.
- NEVER remove `centers.length > 0` guard — `every()` on empty array returns true (vacuous truth) → would auto-select with undefined.
- NEVER fire auto-select for COACHING_CENTER — picker must still show.
- ⛔ ASK PERMISSION before any change.

---

### Fix #98 — FOOTER_VIDEO banner type — compact video ad strip in footer (83bff7a + 245261c)

Full-stack addition of a new `FOOTER_VIDEO` banner type for advertising in the footer area of dashboards.

**Backend changes:**
- `BannerType.java` (center-svc): added `FOOTER_VIDEO` enum value (4th value after HERO/TICKER/VIDEO).
- `V23__extend_banner_type_footer_video.sql`: drops and recreates `chk_banner_type` CHECK constraint to include FOOTER_VIDEO. Applied manually as superuser (DB user lacks DDL rights); flyway_schema_history row inserted manually with checksum `359464780`.

**Frontend changes:**
- `FooterBanner.tsx`: completely rewritten from a 48px HERO text strip to a 160px compact video player. Filters `bannerType === 'FOOTER_VIDEO'` (previously rendered HERO banners). Supports `videoUrl`, `imageUrl` (poster/fallback), `linkUrl`/`linkLabel`. Controls: Play/Pause toggle + Mute/Unmute toggle + Link button. Auto-advance interval pauses when `paused===true`. Prev/Next chevrons + dot nav for multiple banners. Video `onload` respects paused state before calling `play()`.
- `AdminBannersPage.tsx`: added `FOOTER_VIDEO` dropdown option ("Video Advertisement (Footer)"), amber badge colour, renamed existing VIDEO option to "Video Advertisement (Header)". Video URL required warning covers both VIDEO and FOOTER_VIDEO.

**DB record created:** SchoolWear Pro FOOTER_VIDEO banner (id `ad70e9f6`), audience=ALL, active, FOOTER_VIDEO type, videoUrl set.

**Play/pause patch (245261c):**
- `paused` state: `const [paused, setPaused] = useState(false)`
- Auto-advance `setInterval` early-returns when `paused` (interval cleared)
- `useEffect` on `paused` → `videoRef.current.pause()` or `play()`
- Banner-switch `useEffect` calls `play()` only when `!paused`
- Play/Pause button (lucide `Play`/`Pause` icons) renders before mute toggle

**⛔ PERMANENT RULES:**
- NEVER conflate FOOTER_VIDEO with VIDEO — they render in different locations (VIDEO=header full-bleed, FOOTER_VIDEO=footer 160px strip).
- NEVER add `loop` attribute to the FooterBanner `<video>` element — loop suppresses `onEnded`, breaking cyclic rotation.
- NEVER remove the `if (!paused)` guard before `play()` in the banner-switch useEffect.
- Flyway DDL permission pattern: center_schema ALTER TABLE must be run as `srikanth` superuser and flyway_schema_history row inserted manually.
- ⛔ ASK PERMISSION before any change.

---

### Fix #99 — Remove auto-open modal on page load for Jobs / Staff / Library (d0688db)

Fix #96 added `autoOpenedRef + useEffect` to auto-open PostJobModal / CreateStaffModal / UploadWizard when `isSchoolOrCollege` resolved true. This was invisible before Fix #97's root-cause fix (all centers stored as COACHING_CENTER, so condition never fired). After Fix #97 properly classified centers as SCHOOL, the modal opened the moment a user navigated to Jobs/Staff/Library — not enterprise UX.

Removed auto-open entirely from all three pages:
- `AdminJobsPage.tsx`: removed `autoOpenedRef` + `useEffect` block
- `AdminStaffPage.tsx`: removed `autoOpenedRef` + `useEffect` block; removed `useRef` from import (no longer used)
- `AdminLibraryPage.tsx`: removed `autoOpenedRef` + `useEffect` block

Users now land on the list view and open the form explicitly by clicking the button.

**⛔ PERMANENT RULES:**
- NEVER add auto-open-on-mount behavior to any page — it is bad UX regardless of center type.
- ⛔ ASK PERMISSION before any change.
