---
name: project-architecture
description: Core project structure, architecture rules, service ports, gateway routing, and non-negotiable conventions
type: project
---

## Project Overview
- **Root**: `/Users/srikanth/IdeaProjects/school-APK`
- **Type**: Maven mono-repo, 20 modules (4 libs + 15 services + student-gateway)
- **Java**: 17 locally (prod: 21 via temurin:21 Docker)
- **Spring Boot**: 3.3.5, Spring Cloud: 2023.0.3
- **groupId**: `com.edutech`, root artifactId: `edutech-platform`
- **Version strategy**: `${revision}` in all POMs, `.mvn/maven.config` sets `1.0.0-SNAPSHOT`

## Architecture — Non-Negotiable Rules
- **Hexagonal**: `domain` → `application` → `infrastructure` → `api`
- Domain layer: zero Spring/framework dependencies
- **No Lombok** — manual constructors, no setters except domain methods
- **No hardcoded values** — `${ENV_VAR}` in YAML, no defaults for secrets
- **Java Records** for all DTOs, domain events, config properties
- **ArchUnit** enforces layer rules at test time
- JPA annotations ARE allowed in domain layer (documented ADR) — NOT a bug
- `JwtProperties`/`OtpProperties` → `application/config/`; `Argon2Properties`/`CaptchaProperties`/`KafkaTopicProperties` → `infrastructure/config/`

## Service Ports (local dev)
- api-gateway: **8180** | auth-svc: **8182** | parent-svc: 8082 | center-svc: 8083
- assess-svc: 8084 | psych-svc: 8085 | ai-gateway-svc: 8086 | career-oracle-svc: 8087
- mentor-svc: 8088 | student-gateway: **8089** | student-profile-svc: 8090
- exam-tracker-svc: 8091 | performance-svc: 8092 | ai-mentor-svc: 8093 | notification-svc: 8094
- gRPC: assess=9093, performance=9094, ai-mentor=9096, career-oracle=9097, mentor=9098
- Postgres: **5432** (LOCAL native — Homebrew `postgresql@16`, NOT Docker) | Redis: 6379 | Kafka: 9092

## Postgres — LOCAL NATIVE (NOT Docker)
- Postgres runs via **Homebrew `postgresql@16`** on `localhost:5432` — the `edutech-postgres` Docker container is NOT started.
- `start-all.sh` starts only: Redis, Kafka, Mailhog, MinIO (and UI companions) in Docker.
- All 15+ service databases already exist in the local Postgres instance.
- **If Postgres is down after reboot**: `brew services start postgresql@16`
- **psql binary**: `/usr/local/Cellar/postgresql@16/<version>/bin/psql`
- ⛔ NEVER run `docker compose up -d` without exclusions — it would also start `edutech-postgres` and conflict with local Postgres on port 5432.

## Gateway Routing (CRITICAL)
- **api-gateway (8180)**: `/api/v1/auth/**`, `/api/v1/otp/**`, `/api/v1/captcha/**` → auth-svc; `/api/v1/parents/**`, `/api/v1/copilot/**` → parent-svc; `/api/v1/centers/**` → center-svc; `/api/v1/exams/**`, `/api/v1/questions/**` → assess-svc; `/api/v1/psych/**` → psych-svc; `/api/v1/ai/**` → ai-gateway-svc; `/api/v1/notifications/**` → notification-svc
- **student-gateway (8089)**: `/api/v1/students/**` → student-profile-svc; `/api/v1/exam-tracker/**` → exam-tracker-svc; `/api/v1/performance/**` → performance-svc; `/api/v1/doubts/**`, `/api/v1/recommendations/**`, `/api/v1/study-plans/**` → ai-mentor-svc; `/api/v1/career-profiles/**`, `/api/v1/career-recommendations/**`, `/api/v1/college-predictions/**` → career-oracle-svc; `/api/v1/mentors/**`, `/api/v1/mentor-sessions/**` → mentor-svc
- **Vite proxy**: student-gateway paths → 8089 (more specific first); catch-all `/api` → 8180
- `/api/v1/otp/**` and `/api/v1/auth/**` are PUBLIC in api-gateway JWT filter

## All Services — COMPLETE ✅ (219 tests, 0 failures)
auth-svc(12) | center-svc(13) | parent-svc(13) | assess-svc(14) | psych-svc(14) | ai-gateway-svc(11) | api-gateway(10) | student-profile-svc(15) | exam-tracker-svc(16) | performance-svc(19) | ai-mentor-svc(15) | career-oracle-svc(17) | mentor-svc(17) | student-gateway(10) | notification-svc(23)

## Pagination Architecture
- Domain port interfaces return `List<T>` — NO Spring `Page`/`Pageable` in domain (ArchUnit)
- Application services / API controllers do in-memory `PageImpl` slicing
- Pattern: `List<T> all = useCase.list(); int start=...; new PageImpl<>(all.subList(...), pageable, all.size())`

## Known Constraints
- `teacher1@test.com` centerId: must have `center_id='fe26add1-da4b-48f7-aa64-e7d5a1d0781a'` in `auth_schema.users`. Without it, `AuthPrincipal.belongsToCenter()` returns false → 403 on `/api/v1/exams/**`. Fix: `UPDATE auth_schema.users SET center_id='fe26add1-da4b-48f7-aa64-e7d5a1d0781a' WHERE email='teacher1@test.com'` then re-login.
- `opentelemetry-spring-boot-starter` NOT in Spring Boot BOM — use `opentelemetry-exporter-otlp` (runtime)
- Virtual threads (`spring.threads.virtual.enabled=true`) require Java 21 — no-op locally
- Flyway `placeholder-replacement: false` required in all services — SQL `${VAR}` treated as Flyway placeholders
- TimescaleDB continuous aggregates require Enterprise — use standard `CREATE OR REPLACE VIEW`
- XML comments must not contain `--`
- common-security brings Redis onto classpath — every service MUST have `spring.data.redis` config
- **ASSESS_SVC_GRPC_PORT**: 9093 (NOT 9092 — conflicts with Kafka)

## Student-Profile-Svc: Parent-Child Linking Endpoints (commit ac81927 — FROZEN)
- `GET /api/v1/students/lookup?email=` — lookup student by email for parent (any auth user)
- `POST /api/v1/students/link-otp/generate` — parent generates 5-min OTP on student record; body: `{studentEmail, parentName}`; X-User-Id = parent userId; does NOT return OTP to parent
- `GET /api/v1/students/me/pending-link` — student polls for incoming OTP; X-User-Id = student userId; 404 if no valid OTP
- `POST /api/v1/students/link-otp/verify` — parent verifies OTP; body: `{studentEmail, otp}`; clears OTP; returns `{studentId, studentName}`
- DB migration V7: `link_otp`, `link_otp_expires_at`, `link_otp_parent_user_id`, `link_otp_parent_name` on `student_schema.students`

## Load Env Vars (CRITICAL — do every new terminal)
```bash
while IFS='=' read -r key val; do [[ -z "$key" || "$key" == \#* ]] && continue; export "$key=$val"; done < .env
```
Always use `--also-make` (`-am`) when building/testing single modules to resolve `${revision}`.
