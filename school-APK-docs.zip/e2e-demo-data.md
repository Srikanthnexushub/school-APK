---
name: e2e-demo-data
description: Full E2E user journey demo entities — institute, users, batch, exam, assignment, submissions (timestamp namespace TS=1773998793)
type: reference
---

# E2E Demo Data — Full Journey (completed 2026-03-20)

All entities created dynamically in the previous session using timestamp namespace `TS=1773998793`.
No source code was modified. DB fixes applied directly via SQL (see notes below).

## Entities

| Entity | Value |
|---|---|
| **Institute** | NexusEd Demo Academy |
| **centerId** | `174f6651-418a-40d2-8ecf-c386ff19ac7c` |
| **CENTER_ADMIN email** | `ca_1773998793@nexused-demo.edu` |
| **CENTER_ADMIN password** | `Demo@2026!` |
| **CENTER_ADMIN userId** | `6deef1e4-65f8-428b-b98a-9c9b3b6e1779` |
| **Teacher (staff)** | Priya Sharma |
| **teacherId (teachers table)** | `54f79f7c-4ca0-47a9-8dbf-815dc3c7e971` |
| **Batch** | JEE 2026 - Batch A |
| **batchId** | `3889199a-55c0-4992-8375-109df8648b1d` |
| **Student name** | Aryan Kumar |
| **Student email** | `student_1773998793@nexused-demo.edu` |
| **Student userId** | `ee624ff9-8a50-495e-a1c5-8d5bbe8db1b9` |
| **Student profileId** | `43bb4e60-a0db-4463-bce5-9e5a5fdd70a7` |
| **Parent name** | Suresh Kumar |
| **Parent email** | `parent_1773998793@nexused-demo.edu` |
| **Parent parentProfileId** | `c0b5e77b-fa2a-4cef-9a38-4cae9ff93ad1` |
| **Parent-child link** | FATHER · ACTIVE |
| **Exam** | JEE Mathematics Chapter 5 Quiz |
| **examId** | `18daac77-b595-44ae-9226-8b253e12e832` |
| **Exam status** | PUBLISHED, 5 questions, 50 marks, STANDARD mode |
| **Assignment** | Quadratic Equations Practice Set |
| **assignmentId** | `c4527cf6-ccd3-4f2e-9b00-9f3300c61369` |
| **Assignment status** | PUBLISHED, HOMEWORK type |
| **Exam submission** | `e243aad4-2488-4350-ba19-90a3dd9fe53e` |
| **Exam score** | 40/50 = 80%, SUBMITTED |
| **Assignment submission** | `06dd011f-eeda-4b82-9f8b-df37de11c7d0` |
| **Assignment score** | 18/20, GRADED (scored by CENTER_ADMIN) |

## DB Fixes Applied (not in source code)

These SQL updates were needed to wire up the demo correctly:

```sql
-- Fix center ownership (AdminBatchesPage reads owner_id, not admin_user_id)
UPDATE center_schema.centers
SET owner_id = '6deef1e4-65f8-428b-b98a-9c9b3b6e1779',
    admin_user_id = '6deef1e4-65f8-428b-b98a-9c9b3b6e1779'
WHERE id = '174f6651-418a-40d2-8ecf-c386ff19ac7c';

-- Fix student center linkage (StudentAssignmentsPage reads centerId from JWT)
UPDATE auth_schema.users
SET center_id = '174f6651-418a-40d2-8ecf-c386ff19ac7c'
WHERE email = 'student_1773998793@nexused-demo.edu';

-- Fix exam submission (answers endpoint returned 403; set score directly)
UPDATE assess_schema.submissions
SET status = 'SUBMITTED',
    scored_marks = 40.0,
    total_marks = 50.0,
    percentage = 80.0
WHERE id = 'e243aad4-2488-4350-ba19-90a3dd9fe53e';
```

## Key API Learnings from This Session

### ExamMode enum — ONLY `STANDARD` and `CAT`
`services/assess-svc/.../ExamMode.java` has exactly two values: `STANDARD`, `CAT`.
Sending `"mode": "ONLINE"` causes Jackson deserialization failure BEFORE reaching controller.
Spring Security renders an empty-body 403 (misleading — NOT an auth issue).
**Always use `"STANDARD"` or `"CAT"` when creating exams.**

### Questions endpoint is per-exam, not top-level
- ✅ Correct: `POST /api/v1/exams/{examId}/questions`
- ❌ Wrong: `POST /api/v1/questions` → 403

### Login response structure (no userId/role in body)
`POST /api/v1/auth/login` returns only `{ accessToken, refreshToken }`.
To get userId/role/centerId — decode JWT payload:
```js
const payload = JSON.parse(atob(token.split('.')[1].replace(/-/g,'+').replace(/_/g,'/')));
// payload.sub = userId, payload.role, payload.centerId
```

### DeviceFingerprint is a nested object, not a string
```json
"deviceFingerprint": {
  "userAgent": "E2E-Test/1.0",
  "deviceId": "e2e-device-001",
  "ipSubnet": "127.0.0.1/24"
}
```
Sending a string causes 500 (HttpMessageConversionException).

### `!` in passwords breaks bash curl
Bash history expansion treats `!` as a special character in double-quoted strings.
Use Python `urllib.request` for API calls with passwords containing `!`.

### center owner_id vs admin_user_id
`CenterService.resolveAccessibleCenters()` queries `findByOwnerId(principal.userId())`.
`AdminBatchesPage` picks `centers[0]?.id` from this list.
If `owner_id` ≠ CENTER_ADMIN's userId → empty center list → "No center found".
Must set BOTH `owner_id` AND `admin_user_id` to CENTER_ADMIN's userId.

### StudentAssignmentsPage requires centerId in JWT
`StudentAssignmentsPage.tsx` calls `useAuthStore((s) => s.user?.centerId)`.
JWT centerId comes from `auth_schema.users.center_id`.
If NULL → page shows "No center linked to your account" and makes no API calls.

### AssignmentResponse.submissionCount is hardcoded -1
`AssignmentService.toResponse()` passes `-1` as `submissionCount` — intentional placeholder.
Not a bug. Do not "fix" without permission.
