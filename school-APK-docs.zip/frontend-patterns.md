---
name: frontend-patterns
description: Critical frontend patterns, fixes, and anti-patterns — Page<> extraction, JSX gotchas, API conventions
type: feedback
---

## Page<> Extraction Pattern (CRITICAL — never skip)
Spring endpoints return `Page<T>`. Frontend MUST use:
```ts
const d = r.data;
return Array.isArray(d) ? d : (d.content ?? []);
```
Applies to ALL `useQuery` calls against Spring-paginated endpoints.

## JSX Falsy Rendering Gotcha
`{0 && "text"}` renders the literal `0` in JSX — only `false`/`null`/`undefined` suppress rendering.
Always use explicit boolean check: `{value > 0 && ...}` or `{!!value && ...}`.

## Key Frontend Fixes (committed)
- **Avatar.tsx**: `const safe = name || '?'` — null guard in both `getGradient` and `getInitials`
- **Parent Copilot routes**: `POST /api/v1/copilot/conversations` (first msg), `POST /api/v1/copilot/conversations/{id}/messages` (follow-ups)
- **ParentDashboardPage fees card**: `outstandingAmount` = sum of PENDING-status payments for selected student from live `feePayments` API; "Pay Now" navigates to `/parent/fees`
- **Question Generator**: `POST /api/v1/ai/generate-questions` implemented in ai-gateway-svc (commit 0245235) — was NEVER previously implemented; always returned mock data. Now calls real LLM (OpenRouter/Anthropic) with JSON parse + fallback template questions. Frontend schema: `{questionText, options[], correctAnswer: int, explanation, difficulty}`
- **Admin portal**: AdminBatchesPage (`/admin/batches`) + AdminAssessmentsPage (`/admin/assessments`) — fully live, no mock data
- **No mock data**: MentorPortalDashboardPage, MentorPortalSessionsPage, CareerOraclePage, PsychometricPage all use live APIs only
- **PsychometricPage**: 10-question Big Five quiz → 0–1 scores → POST /psych/profiles/{id}/sessions (INITIAL) → complete → radar + RIASEC + learning style
- **psych-svc endpoint**: `GET /api/v1/psych/profiles?studentId={id}` OR `?centerId={id}`
- **Teacher portal route**: `/mentor-portal` (NOT `/teacher`) — role `TEACHER`
- **parent1@test.com profile**: name corrected to "Suresh Verma" in `parent_schema.parent_profiles` (was "Priya Sharma" — seed data inconsistency)

## React Hook Form `values` Prop Gotcha (CRITICAL)
`useForm({ values: serverData })` resets ALL fields — including user's in-progress edits — on every React Query refetch (staleTime expires or window focus).
**Always add**: `resetOptions: { keepDirtyValues: true }` when using `values` from a live query.
Without it, typing in a form gets wiped by background refetches.

## Polling/Spinner Anti-Pattern
Never call `setLoading(true)` in a background interval poll. Only show loading spinner on initial mount.
Pattern:
```ts
async function fetchData(showSpinner = false) {
  if (showSpinner) setLoading(true);
  try { ... }
  finally { if (showSpinner) setLoading(false); }
}
useEffect(() => { fetchData(true); }, []);              // initial — show spinner
useEffect(() => {
  const id = setInterval(() => fetchData(false), 10000); // background — silent
  return () => clearInterval(id);
}, []);
```

## 204 vs 404 for "no data" API responses
When a resource is in a "no active state" (e.g., no pending OTP), return `204 No Content` NOT `404 Not Found`.
404 is for "resource doesn't exist". 204 means "exists, nothing to return right now".
Browser always logs `Failed to load resource` for 4xx — 204 is silent.
Pattern: service returns `null` → controller: `return response != null ? ResponseEntity.ok(response) : ResponseEntity.noContent().build()`

## Backend Patterns to Never Break
- **Hibernate @GeneratedValue conflict**: Remove `id = UUID.randomUUID()` from ALL domain factory methods when `@GeneratedValue(strategy = GenerationType.UUID)` is present — causes `DataIntegrityViolationException: Detached entity with generated id has uninitialized version null`
- **student-gateway RequestIdFilter**: Use `ServerHttpRequestDecorator.getHeaders()` override — `mutate().header()` throws on `ReadOnlyHttpHeaders` in Spring 6.1
- **assess-svc student access**: ExamService.getExam + QuestionService.listQuestions allow STUDENT role on PUBLISHED exams
